﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


public class DataLibBLL
{
    public int Product_Id { get; set; }
    public string Product_Name { get; set; }
    public int Product_Price { get; set; }
    public int Product_Price_high { get; set; }
    public string Product_Introduction { get; set; }
    public string Product_Specification { get; set; }
    public string Product_PhotoPath1 { get; set; }
    public string Product_PhotoPath2 { get; set; }
    public string Product_PhotoPath3 { get; set; }
    public int Factory_Id { get; set; }
    public string Factory_Name { get; set; }
    public string Factory_Contact { get; set; }
    public string Factory_Phone { get; set; }
    public string Factory_Fax { get; set; }
    public string Factory_Email { get; set; }
    public string Factory_Address { get; set; }
    public string Factory_TaxID { get; set; }
}