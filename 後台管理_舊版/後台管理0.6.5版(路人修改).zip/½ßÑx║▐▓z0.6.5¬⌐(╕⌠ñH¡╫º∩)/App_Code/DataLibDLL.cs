﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

/// <summary>
/// DataLibDLL 的摘要描述
/// </summary>
public class DataLibDLL
{
    SqlConnection cn;
    SqlCommand cmd;
    SqlDataAdapter da = new SqlDataAdapter();
    DataSet ds = new DataSet();

	public DataLibDLL()
	{
        cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["DBiii3rdConnectionString"].ConnectionString);
	}
    public string Conn_String()
    {        
        return cn.ConnectionString;
    }
    public DataSet Select_Product()
    {
        cn.Open();
        cmd = new SqlCommand("SELECT p.pId, p.pName, p.pPrice, p.pInformation, p.pSpecifications, p.pPath, p.pPath2, p.pPath3, f.fId ,f.fName FROM dbo.Products p inner join dbo.Factory f on p.fId=f.fId", cn);
        da.SelectCommand = cmd;
        DataTable prd = new DataTable();
        da.Fill(ds, "prd");
        cn.Close();
        cn.Dispose();
        return ds;
    }

    public DataSet Select_Product_search(DataLibBLL cob)
    {
        cn.Open();
        string mysearchstring = "SELECT p.pId, p.pName, p.pPrice, p.pInformation, p.pSpecifications, p.pPath, p.pPath2, p.pPath3, f.fId ,f.fName FROM dbo.Products p inner join dbo.Factory f on p.fId=f.fId Where 1=1 ";
        if (cob.Product_Id != -1) 
        {
            mysearchstring += " and p.pId = @pid";
        }
        if (cob.Product_Name != "") {
            mysearchstring += " and p.pName Like '%'+ @pname +'%'"; 
        }
        if (cob.Product_Price != -1 && cob.Product_Price_high != -1 )
        {
            mysearchstring += " and p.pPrice between @pprice1 and @pprice2 ";
        }else if(cob.Product_Price != -1 && cob.Product_Price_high == -1 )
        {
            mysearchstring += " and p.pPrice >= @pprice1 ";
        }else if(cob.Product_Price == -1 && cob.Product_Price_high != -1 )
        {
            mysearchstring += " and p.pPrice <= @pprice2 ";
        }
        //if (cob.Product_Introduction != "") {mysearchstring += " and p.pInformation Like '%'+ @pintro +'%'";}
        //if (cob.Product_Specification != "") { mysearchstring += " and p.pSpecifications Like '%'+ @pSpec +'%'"; }
        if (cob.Factory_Name != "") 
        {
            mysearchstring += " and f.fName Like '%'+ @fname +'%'"; 
        }
        //cmd = new SqlCommand("SELECT p.pId, p.pName, p.pPrice, p.pInformation, p.pSpecifications, p.pPath, p.pPath2, p.pPath3, f.fId ,f.fName FROM dbo.Products p inner join dbo.Factory f on p.fId=f.fId Where (p.pName Like '%'+ @name +'%')", cn);
        cmd = new SqlCommand(mysearchstring, cn);
        if (cob.Product_Id != -1) 
        {
            cmd.Parameters.AddWithValue("@pid", cob.Product_Id); 
        }
        if (cob.Product_Name != "")
        { 
            cmd.Parameters.AddWithValue("@pname", cob.Product_Name);        
        }
        if (cob.Product_Price != -1 && cob.Product_Price_high != -1)
        {
            cmd.Parameters.AddWithValue("@pprice1", cob.Product_Price);
            cmd.Parameters.AddWithValue("@pprice2", cob.Product_Price_high);
        }
        else if (cob.Product_Price != -1 && cob.Product_Price_high == -1)
        { 
            cmd.Parameters.AddWithValue("@pprice1", cob.Product_Price);
        }
        else if (cob.Product_Price == -1 && cob.Product_Price_high != -1)
        { 
            cmd.Parameters.AddWithValue("@pprice2", cob.Product_Price_high);
        }
        if (cob.Factory_Name != "")
        {
            cmd.Parameters.AddWithValue("@fname", cob.Factory_Name);
        }
        da.SelectCommand = cmd;
        DataTable prd_search = new DataTable();
        da.Fill(ds, "prd_search");
        cn.Close();
        cn.Dispose();
        return ds;
    }
    public DataSet Select_Product_detail(int pid)
    {
        cn.Open();
        cmd = new SqlCommand("SELECT p.pId, p.pName, p.pPrice, p.pInformation,p.pSpecifications, p.pPath, p.pPath2, p.pPath3, f.fId ,f.fName FROM dbo.Products p inner join dbo.Factory f on p.fId=f.fId where p.pId = @pid", cn);
        cmd.Parameters.AddWithValue("@pid", pid);
        da.SelectCommand = cmd;
        DataTable prd = new DataTable();
        da.Fill(ds, "prd_detail");
        cn.Close();
        cn.Dispose();
        return ds;
    }
    public DataSet Select_Product_lastpid()
    {
        cn.Open();
        cmd = new SqlCommand("SELECT TOP 1 p.pId, p.pName, p.pPrice, p.pInformation, p.pSpecifications, p.pPath, p.pPath2, p.pPath3, f.fId ,f.fName FROM dbo.Products p inner join dbo.Factory f on p.fId=f.fId order by p.pId desc", cn);
        da.SelectCommand = cmd;
        DataTable prd_lastpid = new DataTable();
        da.Fill(ds, "prd_lastpid");
        cn.Close();
        cn.Dispose();
        return ds;
    }

    public void Insert_Product(DataLibBLL cob)
    {

        cmd = new SqlCommand("INSERT INTO Products (pName, pPrice, pInformation, pSpecifications, pPath, pPath2, pPath3, fId) VALUES (@name, @price, @intro, @spec, @photo1, @photo2, @photo3, @fid)", cn);
        cmd.Parameters.AddWithValue("@name", cob.Product_Name);
        cmd.Parameters.AddWithValue("@price", cob.Product_Price);
        cmd.Parameters.AddWithValue("@intro", cob.Product_Introduction);
        cmd.Parameters.AddWithValue("@spec", cob.Product_Specification);
        cmd.Parameters.AddWithValue("@photo1", cob.Product_PhotoPath1);
        cmd.Parameters.AddWithValue("@photo2", cob.Product_PhotoPath2);
        cmd.Parameters.AddWithValue("@photo3", cob.Product_PhotoPath3);
        cmd.Parameters.AddWithValue("@fid", cob.Factory_Id);
        cn.Open();
        cmd.ExecuteNonQuery();
        cn.Close();
        cn.Dispose();
    }
    public void Insert_Product_Transaction(DataLibBLL cob)
    {
        cmd = new SqlCommand("INSERT INTO Products (pName, pPrice, pInformation, pSpecifications, pPath, pPath2, pPath3, fId) VALUES (@name, @price, @intro, @spec, @photo1, @photo2, @photo3, @fid)", cn);
        cmd.Parameters.AddWithValue("@name", cob.Product_Name);
        cmd.Parameters.AddWithValue("@price", cob.Product_Price);
        cmd.Parameters.AddWithValue("@intro", cob.Product_Introduction);
        cmd.Parameters.AddWithValue("@spec", cob.Product_Specification);
        cmd.Parameters.AddWithValue("@photo1", cob.Product_PhotoPath1);
        cmd.Parameters.AddWithValue("@photo2", cob.Product_PhotoPath2);
        cmd.Parameters.AddWithValue("@photo3", cob.Product_PhotoPath3);
        cmd.Parameters.AddWithValue("@fid", cob.Factory_Id);
        cmd.Transaction = tran;
        cmd.ExecuteNonQuery();
    }
    public void Update_Product(DataLibBLL cob)
    {
        cn.Open();
        cmd = new SqlCommand("UPDATE Products SET pName=@name, pPrice=@price, pInformation=@intro, pSpecifications=@spec, pPath=@photo1, pPath2=@photo2, pPath3=@photo3, fId=@fid WHERE pId=@pid", cn);
        cmd.Parameters.AddWithValue("@pid", cob.Product_Id);
        cmd.Parameters.AddWithValue("@name", cob.Product_Name);
        cmd.Parameters.AddWithValue("@price", cob.Product_Price);
        cmd.Parameters.AddWithValue("@intro", cob.Product_Introduction);
        cmd.Parameters.AddWithValue("@spec", cob.Product_Specification);
        cmd.Parameters.AddWithValue("@photo1", cob.Product_PhotoPath1);
        cmd.Parameters.AddWithValue("@photo2", cob.Product_PhotoPath2);
        cmd.Parameters.AddWithValue("@photo3", cob.Product_PhotoPath3);
        cmd.Parameters.AddWithValue("@fid", cob.Factory_Id);
        cmd.ExecuteNonQuery();
        cn.Close();
        cn.Dispose();
    }
    public void Delete_Product(int cid)
    {
        cmd = new SqlCommand("DELETE Products WHERE pId=@pid", cn);
        cmd.Parameters.AddWithValue("@pid", cid);
        cn.Open();
        cmd.ExecuteNonQuery();
        cn.Close();
        cn.Dispose();
    }
    public DataSet Select_Factory()
    {
        cn.Open();
        cmd = new SqlCommand("SELECT * FROM Factory", cn);
        da.SelectCommand = cmd;
        DataTable fac = new DataTable();
        da.Fill(ds, "fac");
        cn.Close();
        cn.Dispose();
        return ds;
    }
    //----------------------------------------------------------------------------------

    public DataTable Select_Factory_id()
    {
        cn.Open();
        cmd = new SqlCommand("SELECT fId, fName FROM Factory", cn);
        da.SelectCommand = cmd;
        DataTable facid = new DataTable();
        da.Fill(facid);
        cn.Close();
        cn.Dispose();
        return facid;
    }

    public void Insert_Factory(DataLibBLL cob)
    {
        cn.Open();
        cmd = new SqlCommand("INSERT INTO Factory(fName, fContact, fPhone, fFax, fEmail, fAddress, fTaxID) VALUES (@name, @cont, @phone, @fax, @email, @addr, @taxid)", cn);
        cmd.Parameters.AddWithValue("@name", cob.Factory_Name);
        cmd.Parameters.AddWithValue("@cont", cob.Factory_Contact);
        cmd.Parameters.AddWithValue("@phone", cob.Factory_Phone);
        cmd.Parameters.AddWithValue("@fax", cob.Factory_Fax);
        cmd.Parameters.AddWithValue("@email", cob.Factory_Email);
        cmd.Parameters.AddWithValue("@addr", cob.Factory_Address);
        cmd.Parameters.AddWithValue("@taxid", cob.Factory_TaxID);
        cmd.ExecuteNonQuery();
        cn.Close();
        cn.Dispose();
    }
    public SqlConnection GetConnection()
    {
        cn.Open();
        return cn;
    }
    SqlTransaction tran;
    public SqlTransaction TranBegin()
    {
        tran = cn.BeginTransaction();
        return tran;
    }
    public void TranCommit()
    {
        tran.Commit();
    }
    public void TranRollback()
    {
        tran.Rollback();
    }
    public void Insert_Factory_Transaction(DataLibBLL cob)
    {
        cmd = new SqlCommand("INSERT INTO Factory(fName, fContact, fPhone, fFax, fEmail, fAddress, fTaxID) VALUES (@name, @cont, @phone, @fax, @email, @addr, @taxid)", cn);
        cmd.Parameters.AddWithValue("@name", cob.Factory_Name);
        cmd.Parameters.AddWithValue("@cont", cob.Factory_Contact);
        cmd.Parameters.AddWithValue("@phone", cob.Factory_Phone);
        cmd.Parameters.AddWithValue("@fax", cob.Factory_Fax);
        cmd.Parameters.AddWithValue("@email", cob.Factory_Email);
        cmd.Parameters.AddWithValue("@addr", cob.Factory_Address);
        cmd.Parameters.AddWithValue("@taxid", cob.Factory_TaxID);
        cmd.Transaction = tran;
        cmd.ExecuteNonQuery();
    }
    public void CloseConnection()
    {
        cn.Close();
        cn.Dispose();
    }
    public void Update_Factory(DataLibBLL cob)
    {

        cmd = new SqlCommand("UPDATE Factory SET fName=@name, fContact=@cont, fPhone=@phone, fFax=@fax,  fEmail=@email, fAddress=@addr, fTaxID=@taxid WHERE fId=@fid", cn);
        cmd.Parameters.AddWithValue("@name", cob.Factory_Name);
        cmd.Parameters.AddWithValue("@cont", cob.Factory_Contact);
        cmd.Parameters.AddWithValue("@phone", cob.Factory_Phone);
        cmd.Parameters.AddWithValue("@fax", cob.Factory_Fax);
        cmd.Parameters.AddWithValue("@email", cob.Factory_Email);
        cmd.Parameters.AddWithValue("@addr", cob.Factory_Address);
        cmd.Parameters.AddWithValue("@taxid", cob.Factory_TaxID);
        cmd.Parameters.AddWithValue("@fid", cob.Factory_Id);
        cn.Open();
        cmd.ExecuteNonQuery();
        cn.Close();
        cn.Dispose();
    }
    public void Delete_Factory(int cid)
    {
        cmd = new SqlCommand("DELETE Factory WHERE fId=@fid", cn);
        cmd.Parameters.AddWithValue("@fid", cid);
        cn.Open();
        cmd.ExecuteNonQuery();
        cn.Close();
        cn.Dispose();
    }
    public DataSet Select_Factory_search(DataLibBLL cob)
    {
        cn.Open();
        string mysearchstring = "SELECT * FROM Factory Where 1=1 ";
        if (cob.Factory_Id != -1)
        {
            mysearchstring += " and fId = @fid";
        }        
        if (cob.Factory_Name != "")
        {
            mysearchstring += " and fName Like '%'+ @name +'%'";
        }
        if (cob.Factory_Contact != "")
        {
            mysearchstring += " and fContact Like '%'+ @cont +'%'";
        }
        if (cob.Factory_Phone != "")
        {
            mysearchstring += " and fPhone Like '%'+ @phone +'%'";
        }
        if (cob.Factory_Fax != "")
        {
            mysearchstring += " and fFax Like '%'+ @fax +'%'";
        }
        if (cob.Factory_Email != "")
        {
            mysearchstring += " and fEmail Like '%'+ @email +'%'";
        }
        if (cob.Factory_Address != "")
        {
            mysearchstring += " and fAddress Like '%'+ @addr +'%'";
        }
        if (cob.Factory_TaxID != "")
        {
            mysearchstring += " and fTaxID Like '%'+ @taxid +'%'";
        }

        cmd = new SqlCommand(mysearchstring, cn);
        if (cob.Product_Id != -1)
        {
            cmd.Parameters.AddWithValue("@fid", cob.Factory_Id);
        }
        if (cob.Factory_Name != "")
        {
            cmd.Parameters.AddWithValue("@name", cob.Factory_Name);
        }
        if (cob.Factory_Contact != "")
        {
            cmd.Parameters.AddWithValue("@cont", cob.Factory_Contact);
        }
        if (cob.Factory_Phone != "")
        {
            cmd.Parameters.AddWithValue("@phone", cob.Factory_Phone);
        }
        if (cob.Factory_Fax != "")
        {
            cmd.Parameters.AddWithValue("@fax", cob.Factory_Fax);
        }
        if (cob.Factory_Email != "")
        {
            cmd.Parameters.AddWithValue("@email", cob.Factory_Email);
        }
        if (cob.Factory_Address != "")
        {
            cmd.Parameters.AddWithValue("@addr", cob.Factory_Address);
        }
        if (cob.Factory_TaxID != "")
        {
            cmd.Parameters.AddWithValue("@taxid", cob.Factory_TaxID);
        }

        da.SelectCommand = cmd;
        DataTable fac_search = new DataTable();
        da.Fill(ds, "fac_search");
        cn.Close();
        cn.Dispose();
        return ds;
    }
}