﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class 首頁模擬_150611_這是首頁 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Button btn = new Button();
        btn.Text = "回家";
        btn.CssClass = "btn btn-danger";
        btn.Click += new EventHandler(btn_click);
        put_btn.Controls.Add(btn);

        ListView1.DataSourceID = "SqlDataSource1";
        ListView1.DataBind();

        select_count.InnerText = "在後台選擇了" + ListView1.Items.Count.ToString() + "筆產品" ;
    }
    private void btn_click(object sender,EventArgs e) {
        Response.Redirect("../後台管理/BackManagement.aspx");
    }

}