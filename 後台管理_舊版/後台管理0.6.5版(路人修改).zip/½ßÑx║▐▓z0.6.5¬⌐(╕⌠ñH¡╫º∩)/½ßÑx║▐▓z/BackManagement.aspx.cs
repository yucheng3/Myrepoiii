﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.UI.HtmlControls;

public partial class 後台管理_BackManagement : System.Web.UI.Page
{
    SqlConnectionStringBuilder scsb;
    SqlConnection conn;
    SqlCommand cmd;

    protected void Page_Load(object sender, EventArgs e)
    {
        //150611_HTML被我砍掉惹~~~
        //DataLibDLL dataLib = new DataLibDLL();
        //SqlDataSource1.ConnectionString = dataLib.Conn_String();
        //SqlDataSource2.ConnectionString = dataLib.Conn_String();


        //150615一早起來不知道要做啥
        Button btn = new Button();
        btn.Text = "前往首頁模擬觀看結果";
        btn.CssClass = "btn btn-default";
        btn.Click += new EventHandler(btnToDemo_click);
        put_btn_h2.Controls.Add(btn);

        if (!IsPostBack) {
            ListView1.DataSourceID = "SqlDataSource3";
            ListView1.DataBind();
        }
        CheckAndChange();
        

    }
    private void CheckAndChange() {
        for (int i = 0; i < ListView1.Items.Count; i++)
        {
            if (((CheckBox)ListView1.Items[i].FindControl("boolCheckBox")).Checked == true)
            {
                ((HtmlGenericControl)ListView1.Items[i].FindControl("panelTitle")).Attributes["class"] = "panel panel-primary";
                ((HtmlGenericControl)ListView1.Items[i].FindControl("panel_heading")).InnerText = "已經點選此項目顯示載首頁上";
            }
            else
            {
                ((HtmlGenericControl)ListView1.Items[i].FindControl("panel_heading")).InnerText = "未選擇項目";
            }
        }
    }
    private static bool IsChecked(ListViewDataItem item, string checkBoxId)
    {
        var control = item.FindControl(checkBoxId) as CheckBox;
        if (control == null)
        {
            return false;
        }
        return control.Checked;
    }
    protected void ListView3_SelectedIndexChanging(object sender, ListViewSelectEventArgs e)
    {
        string index;
        index = e.NewSelectedIndex.ToString();
        int ing = Convert.ToInt32(index);

        //ListView list = (ListView)sender;
        //Label1.Text = list.SelectedIndex.ToString();
        //Label1.Text = index;
    }

    //150615gogoDemo
    private void btnToDemo_click(object sender, EventArgs e) {
        Response.Redirect("../首頁模擬(150611)/這是首頁.aspx");
    }
    public void btnBoolChange_click(object sender,EventArgs e) {        
        Button btn = (Button)sender;
        string x = btn.Text;
        ChangeBool(x);
        //Label1.Text = ListView1.Items.Count.ToString();
        //ListView1.
        CheckAndChange();
    }
    bool boolState;
    private void ChangeBool(string pId) {
        //Response.Write("生日是每天都需要的!!");
        //Label2.Text += "生日是每天都需要的!!";
        scsb = new SqlConnectionStringBuilder();
        scsb.DataSource = "CR4-14\\MSSQLSERVER2013";
        scsb.InitialCatalog = "DBiii3rd";
        scsb.IntegratedSecurity = true;
        conn = new SqlConnection(scsb.ConnectionString);
        conn.Open();
        cmd = new SqlCommand("Update Customer set bool = bool-1 Where cId = " + pId, conn);
        cmd.ExecuteNonQuery();
        //SqlCommand cmdSelect = new SqlCommand("Select bool from Customer Where cId = " + pId, conn);
        ListView1.DataSourceID = "SqlDataSource3";
        ListView1.DataBind();

        conn.Close();
        conn.Dispose();
    }


    public void btnAbout_click(object sender,EventArgs e) {
        group_about.Visible = true;//只顯示關於我們
        group_HotProducts.Visible = false;
        formgroup.Visible = false;
    }
    public void btnProducts_click(object sender,EventArgs e) {
        group_about.Visible = false;//只顯示產品列表
        group_HotProducts.Visible = true;
        formgroup.Visible = false;
    }
    public void btnCustomer_click(object sender,EventArgs e) {
        group_about.Visible = false;//只顯示客戶資料
        group_HotProducts.Visible = false;
        formgroup.Visible = true;
    }
    public void btnAll_click(object sender,EventArgs e) {
        group_about.Visible = true;//你不會看英文嘛?顯示全部
        group_HotProducts.Visible = true;
        formgroup.Visible = true;
    }

    protected void ListView1_SelectedIndexChanging(object sender, ListViewSelectEventArgs e)
    {
        //Label2.Text = e.NewSelectedIndex.ToString();
    }


    protected void ListView1_ItemCommand(object sender, ListViewCommandEventArgs e)
    {
        //int index = ((ListViewDataItem)e.Item).DisplayIndex;
        //Label1.Text = index.ToString();
        //Label1.Text = ((Button)e.Item.FindControl("GGGButton")).Text;
    }
}