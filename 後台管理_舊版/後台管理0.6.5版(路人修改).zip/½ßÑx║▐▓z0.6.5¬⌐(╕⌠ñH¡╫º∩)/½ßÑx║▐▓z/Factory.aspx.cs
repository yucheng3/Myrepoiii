﻿using NPOI.HPSF;
using NPOI.HSSF;
using NPOI.HSSF.UserModel;
using NPOI.POIFS.FileSystem;
using NPOI.SS.UserModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            FillGridView();
        }
    }
    private void FillGridView()
    {

        GridView1.DataSource = Factory_search();
        GridView1.DataBind();
    }
    private DataSet Factory_search()
    {
        DataLibBLL f = new DataLibBLL();
        f.Factory_Id = (txtsearch0.Text.ToString().Trim() == "" ? -1 : Convert.ToInt32(txtsearch0.Text.Trim()));
        f.Factory_Name = (txtsearch1.Text.ToString().Trim() == "" ? "" : txtsearch1.Text.ToString().Trim());
        f.Factory_Contact= (txtsearch2.Text.ToString().Trim() == "" ? "" : txtsearch2.Text.ToString().Trim());
        f.Factory_Phone = (txtsearch3.Text.ToString().Trim() == "" ? "" : txtsearch3.Text.ToString().Trim());
        f.Factory_Fax = (txtsearch4.Text.ToString().Trim() == "" ? "" : txtsearch4.Text.ToString().Trim());
        f.Factory_Email = (txtsearch5.Text.ToString().Trim() == "" ? "" : txtsearch5.Text.ToString().Trim());
        f.Factory_Address = (txtsearch6.Text.ToString().Trim() == "" ? "" : txtsearch6.Text.ToString().Trim());
        f.Factory_TaxID = (txtsearch7.Text.ToString().Trim() == "" ? "" : txtsearch7.Text.ToString().Trim());
        DataLibDLL obj = new DataLibDLL();
        DataSet ds = obj.Select_Factory_search(f);
        obj = null;
        return ds;
    }

    //搜尋
    protected void btnsearch_Click(object sender, EventArgs e)
    {

        DataSet ds = Factory_search();
        if (ds.Tables["fac_search"].Rows.Count > 0)
        {
            //將資料記錄顯示在GridView1制項上
            GridView1.Visible = true;
            lblwarm.Visible = false;
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }
        else
        {
            GridView1.Visible = false;
            lblwarm.Visible = true;
            lblwarm.Text = "查無相關廠商資料資料";
        }
    }
    //排序
    protected void GridView1_Sorting(object sender, GridViewSortEventArgs e)
    {
        string sortExp = e.SortExpression;
        string direction = "";
        if (SortDir == SortDirection.Ascending)
        {
            SortDir = SortDirection.Descending;
            direction = "DESC";
        }
        else
        {
            SortDir = SortDirection.Ascending;
            direction = "ASC";
        }
        DataSet ds = Factory_search();
        DataTable dt = new DataTable();
        dt = ds.Tables["fac_search"];
        dt.DefaultView.Sort = sortExp + " " + direction;
        GridView1.DataSource = dt;
        GridView1.DataBind();
    }
    public SortDirection SortDir
    {
        get
        {
            if (ViewState["SortDir"] == null)
            {
                ViewState["SortDir"] = SortDirection.Ascending;
            }
            return (SortDirection)ViewState["SortDir"];
        }
        set
        {
            ViewState["SortDir"] = value;
        }
    }
    //分頁
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        FillGridView();
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        DataLibBLL f = new DataLibBLL();
        f.Factory_Id = Convert.ToInt32(((Label)GridView1.Rows[e.RowIndex].FindControl("lblfid1")).Text);
        DataLibDLL obj = new DataLibDLL();
        obj.Delete_Factory(f.Factory_Id);
        FillGridView();
        obj = null;
    }
    //進入編輯模式
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        FillGridView();
    }
    //取消編輯
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        FillGridView();
    }
    //更新
    int index;
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        index = GridView1.EditIndex;
        if (CheckUpdateInput() == false)
        {
            ((Label)GridView1.Rows[e.RowIndex].FindControl("lblfname2")).Text = input_fname;
            ((Label)GridView1.Rows[e.RowIndex].FindControl("lblfmail2")).Text = input_femail;
            ((Label)GridView1.Rows[e.RowIndex].FindControl("lblfphone2")).Text = input_fphone;
            ((Label)GridView1.Rows[e.RowIndex].FindControl("lblfaddress2")).Text = input_faddress;
            ((Label)GridView1.Rows[e.RowIndex].FindControl("lblftaxid2")).Text = input_ftaxid;
        }
        else
        {
            DataLibBLL f = new DataLibBLL();
            f.Factory_Name = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtfname")).Text;
            f.Factory_Contact = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtfcont")).Text;
            f.Factory_Phone = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtfphone")).Text;
            f.Factory_Fax = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtftax")).Text;
            f.Factory_Email = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtfmail")).Text;
            f.Factory_Address = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtfaddr")).Text;
            f.Factory_TaxID = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtftaxid")).Text;
            f.Factory_Id = Convert.ToInt32(((Label)GridView1.Rows[e.RowIndex].FindControl("lblfid2")).Text);
            DataLibDLL obj = new DataLibDLL();
            obj.Update_Factory(f);
            GridView1.EditIndex = -1;
            FillGridView();
            obj = null;
        }
    }
    protected bool CheckUpdateInput()
    {
        //Input輸入檢查
        bool status = true;
        input_fname = "";
        input_fphone = "";
        input_femail = "";
        input_faddress = "";
        input_ftaxid = "";
        //檢查商品名稱不可空白
        if (String.IsNullOrEmpty(((TextBox)GridView1.Rows[index].FindControl("txtfname")).Text.Trim()))
        {
            status = false;
            input_fname = "廠商名稱不可空白";
        }
        else { input_fname = ""; }

        if (String.IsNullOrEmpty(((TextBox)GridView1.Rows[index].FindControl("txtfphone")).Text.Trim()))
        {
            status = false;
            input_fphone = "廠商電話不可空白";
        }
        else { input_fphone = ""; }
        if (String.IsNullOrEmpty(((TextBox)GridView1.Rows[index].FindControl("txtfmail")).Text.Trim()))
        {
            status = false;
            input_femail = "Email不可空白";
        }
        else if (!String.IsNullOrEmpty(((TextBox)GridView1.Rows[index].FindControl("txtfmail")).Text.Trim()))
        {
            string reg = @"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*";
            if (Regex.IsMatch(((TextBox)GridView1.Rows[index].FindControl("txtfmail")).Text.Trim(), reg))
            { }
            else
            {
            status = false;
            input_femail = "Email格式錯誤";
            }
        }
        else { input_femail = ""; }
        if (String.IsNullOrEmpty(((TextBox)GridView1.Rows[index].FindControl("txtfaddr")).Text.Trim()))
        {
            status = false;
            input_faddress = "廠商地址不可空白";
        }
        else { input_faddress = ""; }
        if (String.IsNullOrEmpty(((TextBox)GridView1.Rows[index].FindControl("txtftaxid")).Text.Trim()))
        {
            status = false;
            input_ftaxid = "廠商統一編號不可空白";
        }
        else if (!String.IsNullOrEmpty(((TextBox)GridView1.Rows[index].FindControl("txtftaxid")).Text.Trim()))
        {
            if (CheckCompanyN(((TextBox)GridView1.Rows[index].FindControl("txtftaxid")).Text.Trim()) == true)
            {

            }
            else
            {
                status = false;
                input_ftaxid = "統一編號格式錯誤";
            }
        }
        else { input_ftaxid = ""; }
        return status;
    }
    

    //新增
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (CheckInsertInput() == false)
        {
            ((Label)GridView1.FooterRow.FindControl("lblfname1")).Text = input_fname;
            ((Label)GridView1.FooterRow.FindControl("lblfphone1")).Text = input_fphone;
            ((Label)GridView1.FooterRow.FindControl("lblfmail1")).Text = input_femail;
            ((Label)GridView1.FooterRow.FindControl("lblfaddress1")).Text = input_faddress;
            ((Label)GridView1.FooterRow.FindControl("lblftaxid1")).Text = input_ftaxid;
        }
        else
        {
            DataLibBLL f = new DataLibBLL();
            f.Factory_Name = ((TextBox)GridView1.FooterRow.FindControl("tbfname")).Text.Trim();
            f.Factory_Contact = ((TextBox)GridView1.FooterRow.FindControl("tbfcont")).Text.Trim();
            f.Factory_Phone = ((TextBox)GridView1.FooterRow.FindControl("tbfphone")).Text.Trim();
            f.Factory_Fax = ((TextBox)GridView1.FooterRow.FindControl("tbffax")).Text.Trim();
            f.Factory_Email = ((TextBox)GridView1.FooterRow.FindControl("tbfmail")).Text.Trim();
            f.Factory_Address = ((TextBox)GridView1.FooterRow.FindControl("tbfaddr")).Text.Trim();
            f.Factory_TaxID = ((TextBox)GridView1.FooterRow.FindControl("tbftaxid")).Text.Trim();
            DataLibDLL obj = new DataLibDLL();
            obj.Insert_Factory(f);
            FillGridView();
            obj = null;
        }
    }
    //新增判斷
    string input_fname = "";
    string input_fphone = "";
    string input_femail = "";
    string input_faddress = "";
    string input_ftaxid = "";
    protected bool CheckInsertInput()
    {
        //Input輸入檢查
        bool status = true;
        input_fname = "";
        input_fphone = "";
        input_femail = "";
        input_faddress = "";
        input_ftaxid = "";
        //檢查商品名稱不可空白
        if (String.IsNullOrEmpty(((TextBox)GridView1.FooterRow.FindControl("tbfname")).Text.Trim()))
        {
            status = false;
            input_fname = "廠商名稱不可空白";
        }
        else { input_fname = ""; }

        if (String.IsNullOrEmpty(((TextBox)GridView1.FooterRow.FindControl("tbfphone")).Text.Trim()))
        {
            status = false;
            input_fphone = "廠商電話不可空白";
        }
        else { input_fphone = ""; }
        if (String.IsNullOrEmpty(((TextBox)GridView1.FooterRow.FindControl("tbfmail")).Text.Trim()))
        {
            status = false;
            input_femail = "Email不可空白";
        }
        else if (!String.IsNullOrEmpty(((TextBox)GridView1.FooterRow.FindControl("tbfmail")).Text.Trim()))
        {
            string reg = @"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*";
            if (Regex.IsMatch(((TextBox)GridView1.FooterRow.FindControl("tbfmail")).Text.Trim(), reg))
            { }
            else
            {
            status = false;
            input_femail = "Email格式錯誤";
            }
        }
        else { input_femail = ""; }
        if (String.IsNullOrEmpty(((TextBox)GridView1.FooterRow.FindControl("tbfaddr")).Text.Trim()))
        {
            status = false;
            input_faddress = "廠商地址不可空白";
        }
        else { input_faddress = ""; }
        if (String.IsNullOrEmpty(((TextBox)GridView1.FooterRow.FindControl("tbftaxid")).Text.Trim()))
        {
            status = false;
            input_ftaxid = "廠商統一編號不可空白";
        }
        else if (!String.IsNullOrEmpty(((TextBox)GridView1.FooterRow.FindControl("tbftaxid")).Text.Trim()))
        {
            if (CheckCompanyN(((TextBox)GridView1.FooterRow.FindControl("tbftaxid")).Text.Trim()) == true)
            {

            }
            else
            {
                status = false;
                input_ftaxid = "統一編號格式錯誤";
            }
        }
        else { input_ftaxid = ""; }
        return status;
    }
    //統一編號驗證
    private Boolean CheckCompanyN(string CompanyId)
    {
        int CompanyNo;
        if (CompanyId == null || CompanyId.Trim().Length != 8)
            return false;
        if (!int.TryParse(CompanyId, out CompanyNo))
            return false;
        int[] Logic = new int[] { 1, 2, 1, 2, 1, 2, 4, 1 };
        int addition, sum = 0, j = 0, x;
        for (x = 0; x < Logic.Length; x++)
        {
            int no = Convert.ToInt32(CompanyId.Substring(x, 1));
            j = no * Logic[x];
            addition = ((j / 10) + (j % 10));
            sum += addition;
        }
        if (sum % 10 == 0)
        {
            return true;
        }
        if (CompanyId.Substring(6, 1) == "7")
        {
            if (sum % 10 == 9)
            {
                return true;
            }
        }
        return false;
    }
    protected void btnoutexcel_Click(object sender, EventArgs e)
    {
        DataSet ds = Factory_search();
        DataTable dt = ds.Tables["fac_search"];
        ExportDataTableToExcel(dt);
    }
    public void ExportDataTableToExcel(DataTable pDataTable)
    {
        int tRowCount = pDataTable.Rows.Count;
        int tColumnCount = pDataTable.Columns.Count;

        Response.Expires = 0;
        Response.Clear();
        Response.Buffer = true;
        Response.Charset = "utf-8";
        Response.ContentEncoding = System.Text.Encoding.UTF8;

        Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        //'Excel 2003 : "application/vnd.ms-excel"
        //'Excel 2007 : "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        Response.AddHeader("Content-Disposition", string.Format("attachment; filename={0}", "factory.xls"));
        Response.Write("<meta http-equiv=Content-Type content=text/html;charset=utf-8>");
        Response.Write("<style type=text/css>");
        Response.Write("td{mso-number-format:\"\\@\";}"); //將所有欄位格式改為"文字"
        Response.Write("</style>");
        Response.Write("<Table borderColor=black border=1>");
        Response.Write("\n <TR>");
        //表頭
        for (int i = 0; i < tColumnCount; i++)
        {
            Response.Write("\n <TD align=\"center\" x:num>");
            Response.Write(pDataTable.Columns[i].ColumnName);
            Response.Write("\n </TD>");
        }
        Response.Write("\n </TR>");
        //表身
        for (int j = 0; j < tRowCount; j++)
        {
            Response.Write("\n <TR>");
            for (int k = 0; k < tColumnCount; k++)
            {
                Response.Write("\n <TD align=\"right\" x:num>");
                Response.Write(pDataTable.Rows[j][k].ToString());
                Response.Write("\n </TD>");
            }
            Response.Write("\n </TR>");
        }
        Response.Write("</Table>");
        Response.End();
    }
    protected void btninsert_excel_Click(object sender, EventArgs e)
    {
        lblwarm.Visible = false;
        lblwarm.Text = "";
        //是否允許上載
        bool fileAllow = false;
        string[] allowExtensions = { ".xls"};
        if ((FileUpload_fac_excel).HasFile)
        {
           //取得上載檔案之延伸檔名，並轉換成小寫字母
            string fileExtension = System.IO.Path.GetExtension((FileUpload_fac_excel).FileName).ToLower();
                        //檢查延伸檔名是否符合限定類型
                        for (int j = 0; j < allowExtensions.Length; j++)
                        {
                            if (fileExtension == allowExtensions[j])
                            {
                                fileAllow = true;
                            }
                            else
                            {
                                lblwarm.Visible = true;
                                lblwarm.Text = "檔案副檔名不符合限定類型";
                            }
                        }
            string savePath = Server.MapPath("~/Excel檔/");
            string filename = FileUpload_fac_excel.FileName;
            if (fileAllow) 
            {
            savePath += filename;
            FileUpload_fac_excel.SaveAs(savePath);
            DataLibBLL f = new DataLibBLL();
            DataLibDLL obj = new DataLibDLL();
            try
            {
                    HSSFWorkbook myWorkbook = new HSSFWorkbook(FileUpload_fac_excel.FileContent);
                    ISheet mySheet = myWorkbook.GetSheetAt(0);
                    DataTable dt = new DataTable();

                    // 將mysheet工作表的第一列存入DATATABLE
                    HSSFRow headerRow = mySheet.GetRow(0) as HSSFRow;
                    for (int i = headerRow.FirstCellNum; i < headerRow.LastCellNum; i++)
                    {
                        if (headerRow.GetCell(i) != null)
                        {
                            DataColumn myColumn = new DataColumn(headerRow.GetCell(i).StringCellValue);
                            dt.Columns.Add(myColumn);
                        }
                    }

                    // 將mysheet第一列後的資料存入DATATABLE
                    for (int i = mySheet.FirstRowNum + 1; i <= mySheet.LastRowNum; i++)
                    {
                        HSSFRow row = mySheet.GetRow(i) as HSSFRow;
                        DataRow myRow = dt.NewRow();
                        for (int j = row.FirstCellNum; j < row.LastCellNum; j++)
                        {
                            if (row.GetCell(j) != null)
                            {
                                myRow[j] = row.GetCell(j).ToString();
                            }
                        }
                        dt.Rows.Add(myRow);
                    }
                    myWorkbook = null;
                    mySheet = null;

                    obj.GetConnection();
                    obj.TranBegin();
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        f.Factory_Name = dt.Rows[i]["fName"].ToString();
                        f.Factory_Contact = dt.Rows[i]["fContact"].ToString();
                        f.Factory_Phone = dt.Rows[i]["fPhone"].ToString();
                        f.Factory_Fax = dt.Rows[i]["fFax"].ToString();
                        f.Factory_Email = dt.Rows[i]["fEmail"].ToString();
                        f.Factory_Address = dt.Rows[i]["fAddress"].ToString();
                        f.Factory_TaxID = dt.Rows[i]["fTaxID"].ToString();
                        obj.Insert_Factory_Transaction(f);
                    }
                    obj.TranCommit();
                    obj.CloseConnection();
                    FillGridView();
                    obj = null;
                    //檢查是否有檔案有即刪除
                    if (File.Exists(savePath))
                    {   
                        File.Delete(savePath);
                    }
                }
                catch (Exception)
                {
                    lblwarm.Visible = true;
                    lblwarm.Text = "EXCEL檔儲存到資料庫失敗!";
                    obj.TranRollback();
                    //檢查是否有檔案有即刪除
                    if (File.Exists(savePath))
                    {
                        File.Delete(savePath);
                    }
                }
            }     
        }else 
            {
                    lblwarm.Visible = true;
                    lblwarm.Text = "未選取EXCEL檔!";
            }

    }
}