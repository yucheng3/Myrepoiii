﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class 後台管理_NewsInsert : System.Web.UI.Page
{
    SqlConnectionStringBuilder scsb = new SqlConnectionStringBuilder();
    SqlConnection conn;
    SqlCommand cmd;

    protected void Page_Load(object sender, EventArgs e)
    {
        div_h1_error_message.Visible = false;

        //這棵八疼是新增按鈕
        Button btnInsert = new Button();
        btnInsert.Text = "新增";
        btnInsert.CssClass = "btn btn-primary";
        btnInsert.OnClientClick = "return confirm('確定新增一筆新聞?')";
        btnInsert.Click += new EventHandler(btnInsert_click);
        put_btn.Controls.Add(btnInsert);
        //怕你看不懂這棵八疼跟你說一下是清除按鈕
        Button btnClear = new Button();
        btnClear.Text = "清除";
        btnClear.CssClass = "btn btn-default";
        btnClear.Click += new EventHandler(btnClear_click);
        put_btn.Controls.Add(btnClear);


    }
    private void btnInsert_click(object sender,EventArgs e) {
        int Error = errorMessage();
        if (Error == 0)
        {
            DataLibDLL datalib = new DataLibDLL();
            conn = new SqlConnection(scsb.ConnectionString = datalib.Conn_String());
            conn.Open();
            cmd = new SqlCommand("Insert INTO News Values ( @nSubject ," +
                " @nContent , @nDate );", conn);

            cmd.Parameters.AddWithValue("@nSubject", tbox_Subject.Text);
            cmd.Parameters.AddWithValue("@nContent", tbox_nContent.Text);
            cmd.Parameters.Add("@nDate", DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"));
            int insert = cmd.ExecuteNonQuery();

            Response.Redirect("../後台管理/News.aspx");
        }
        else {
            div_h1_error_message.Visible = true;
            h2_error_message.InnerText = "少填寫了" + Error +"筆資料";
        }

    }
    private void btnClear_click(object sendeer,EventArgs e) {
        tbox_Subject.Text = "";
        tbox_nContent.Text = "";
    }

    private int errorMessage() { 
        //錯誤訊息
        int Error = 0;
        if (string.IsNullOrEmpty(tbox_Subject.Text))
        {
            fg_tb_subject.Attributes["class"] = "form-group has-error";
            Error++;
        }
        else {
            fg_tb_subject.Attributes["class"] = "form-group has-success";
        }
        if (string.IsNullOrEmpty(tbox_nContent.Text))
        {
            fg_tb_content.Attributes["class"] = "form-group has-error";
            Error++;
        }
        else {
            fg_tb_content.Attributes["class"] = "form-group has-success";
        }

        return Error;
    }


}