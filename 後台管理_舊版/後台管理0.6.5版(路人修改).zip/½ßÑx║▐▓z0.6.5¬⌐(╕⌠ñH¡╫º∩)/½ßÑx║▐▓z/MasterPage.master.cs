﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class 後台管理_MasterPage : System.Web.UI.MasterPage
{
    SqlConnection cn;

    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
}
