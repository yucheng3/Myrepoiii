﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using NPOI.HSSF.UserModel;
using NPOI.HPSF;
using NPOI.HSSF;
using NPOI.POIFS.FileSystem;
using System.Data;
using NPOI.SS.UserModel;
using System.Data.SqlClient;
using System.Configuration;

public partial class 後台管理_Default : System.Web.UI.Page
{
    SqlConnectionStringBuilder scsb;
    static int countClick = 0; // 計算功能開關按鈕點擊次數

    protected void Page_Load(object sender, EventArgs e)
    {
        DataLibDLL dataLib = new DataLibDLL();
        SqlDataSource1.ConnectionString = dataLib.Conn_String();
        SqlDataSource2.ConnectionString = dataLib.Conn_String();
        SqlDataSource3.ConnectionString = dataLib.Conn_String();     

        FileUpload1.Visible = false;
        Label1.Visible = false;
        btnToGridView.Visible = false;
        btnToExcel.Visible = false;
        btnToSQL.Visible = false;

        btnSearch.Visible = false;
        lblId.Visible = false;
        lblName.Visible = false;
        lblPhone.Visible = false;
        lblEmail.Visible = false;
        lblAddress.Visible = false;
        lblTo.Visible = false;
        txtIdEnd.Visible = false;
        txtIdStart.Visible = false;
        txtName.Visible = false;
        txtPhone.Visible = false;
        txtEmail.Visible = false;
        txtAddress.Visible = false;
        btnMultiSearch.Visible = false;
    }
    //protected void LinkButton1_Click(object sender, EventArgs e)
    //{
    //    Response.Redirect("MemberInsert.aspx");
    //}
    protected void btnToExcel_Click(object sender, EventArgs e)
    {
        Response.ClearContent();
        Response.Write("<meta http-equiv=Content-Type content=text/html;charset=utf-8>");
        string excelFileName = "MemberData.xls";
        Response.AddHeader("content-disposition", "attachment;filename=" + Server.UrlEncode(excelFileName));
        Response.ContentType = "application/excel";
        System.IO.StringWriter stringWrite = new System.IO.StringWriter();
        System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);
        ListView1.RenderControl(htmlWrite);
        Response.Write(stringWrite.ToString());
        Response.End();
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        // 解決例外處理'GridView' 的控制項 'GridView' 必須置於有 runat=server 的表單標記之中
    }
    protected void btnToSQL_Click(object sender, EventArgs e)
    {
        scsb = new SqlConnectionStringBuilder();
        scsb.ConnectionString = SqlDataSource1.ConnectionString;
        scsb.IntegratedSecurity = true;

        SqlConnection con = new SqlConnection(scsb.ToString());
        con.Open();
        // 查詢資料庫中最小cId及最大cId
        SqlCommand cmd2 = new SqlCommand(@"SELECT min(cId) FROM Customer", con);
        SqlCommand cmd3 = new SqlCommand(@"SELECT max(cId) FROM Customer", con);
        int cIdMax = Convert.ToInt32(cmd3.ExecuteScalar());
        int[] count = new int[GridView1.Rows.Count]; // 宣告count陣列來存放相同cId的
        // 資料庫資料的cId和匯入資料的cId相同，做Update
        for (int cIdMin = Convert.ToInt32(cmd2.ExecuteScalar()); cIdMin <= cIdMax; cIdMin++)
        {
            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                if (cIdMin == Convert.ToInt32(GridView1.Rows[i].Cells[1].Text))
                {
                    SqlCommand cmd = new SqlCommand(@"Update Customer set cName=@NewName,cAddress=@NewAddress," +
                        "cPhone=@NewPhone,cEmail=@NewEmail,cAccount=@NewAccount,cPassword=@NewPassword Where cId=@Id", con);

                    cmd.Parameters.AddWithValue("@Id", GridView1.Rows[i].Cells[1].Text);
                    cmd.Parameters.AddWithValue("@NewName", GridView1.Rows[i].Cells[2].Text);
                    cmd.Parameters.AddWithValue("@NewAddress", GridView1.Rows[i].Cells[3].Text);
                    cmd.Parameters.AddWithValue("@NewPhone", GridView1.Rows[i].Cells[4].Text);
                    cmd.Parameters.AddWithValue("@NewEmail", GridView1.Rows[i].Cells[5].Text);
                    cmd.Parameters.AddWithValue("@NewAccount", GridView1.Rows[i].Cells[6].Text);
                    cmd.Parameters.AddWithValue("@NewPassword", GridView1.Rows[i].Cells[7].Text);

                    int rows = cmd.ExecuteNonQuery();
                    count[i] = Convert.ToInt32(GridView1.Rows[i].Cells[1].Text);
                }
            }
        }
        int flag = 0;
        // 資料庫資料的cId和匯入資料的cId不同，做Insert        
        for (int i = 0; i < GridView1.Rows.Count; i++)
        {
            for (int j = 0; j < GridView1.Rows.Count; j++)
            {
                if (Convert.ToInt32(GridView1.Rows[i].Cells[1].Text) == count[j])
                {
                    flag = 1;
                }
            }
            if (flag != 1)
            {   // 因cId有設定識別規格，所以要設IDENTITY_INSERT=ON 且指定資料行名稱(cId,cName,cAddress,cPhone,cEmail,cAccount,cPassword)
                SqlCommand cmd = new SqlCommand(@"SET IDENTITY_INSERT Customer ON Insert into " +
                    "Customer (cId,cName,cAddress,cPhone,cEmail,cAccount,cPassword) Values(@cId,@cName,@cAddress,@cPhone,@cEmail,@cAccount,@cPassword)", con);

                cmd.Parameters.AddWithValue("@cId", GridView1.Rows[i].Cells[1].Text);
                cmd.Parameters.AddWithValue("@cName", GridView1.Rows[i].Cells[2].Text);
                cmd.Parameters.AddWithValue("@cAddress", GridView1.Rows[i].Cells[3].Text);
                cmd.Parameters.AddWithValue("@cPhone", GridView1.Rows[i].Cells[4].Text);
                cmd.Parameters.AddWithValue("@cEmail", GridView1.Rows[i].Cells[5].Text);
                cmd.Parameters.AddWithValue("@cAccount", GridView1.Rows[i].Cells[6].Text);
                cmd.Parameters.AddWithValue("@cPassword", GridView1.Rows[i].Cells[7].Text);

                int rows = cmd.ExecuteNonQuery();
            }
            else { flag = 0; }
        }

        con.Close();
        Label1.Visible = true;
        Label1.Text = "~~~ 匯入SQL成功 ~~~!!!";
        FileUpload1.Visible = true;
        btnToGridView.Visible = true;
        btnToExcel.Visible = true;
        btnToSQL.Visible = true;
    }

    protected void btnToGridView_Click(object sender, EventArgs e)
    {
        string savePath = Server.MapPath("~/Excel檔/");

        if (FileUpload1.HasFile)
        {
            string filename = FileUpload1.FileName;
            savePath += filename;
            FileUpload1.SaveAs(savePath);

            try
            {
                HSSFWorkbook myWorkbook = new HSSFWorkbook(FileUpload1.FileContent);
                ISheet mySheet = myWorkbook.GetSheetAt(0);
                DataTable myDT = new DataTable();

                // 將mysheet工作表的第一列存入DATATABLE
                HSSFRow headerRow = mySheet.GetRow(0) as HSSFRow;
                for (int i = headerRow.FirstCellNum; i < headerRow.LastCellNum; i++)
                {
                    if (headerRow.GetCell(i) != null)
                    {
                        DataColumn myColumn = new DataColumn(headerRow.GetCell(i).StringCellValue);
                        myDT.Columns.Add(myColumn);
                    }
                }

                // 將mysheet第一列後的資料存入DATATABLE
                for (int i = mySheet.FirstRowNum + 1; i <= mySheet.LastRowNum; i++)
                {
                    HSSFRow row = mySheet.GetRow(i) as HSSFRow;
                    DataRow myRow = myDT.NewRow();
                    for (int j = row.FirstCellNum; j < row.LastCellNum; j++)
                    {
                        if (row.GetCell(j) != null)
                        {
                            myRow[j] = row.GetCell(j).ToString();
                        }
                    }
                    myDT.Rows.Add(myRow);
                }

                myWorkbook = null;
                mySheet = null;
                DataView myView = new DataView(myDT);
                ListView1.DataSourceID = null;
                ListView1.DataSource = myDT;
                //ListView1.AllowSorting = true;
                ListView1.DataBind();

                Label1.Visible = true;
                Label1.Text = "GridView 上傳成功 ~!";
                FileUpload1.Visible = true;
                btnToGridView.Visible = true;
                btnToExcel.Visible = true;
                btnToSQL.Visible = true;
            }
            catch (Exception ex)
            {
                Response.Write("  Error Message : " + ex.ToString());
            }
        }
        else
        {
            Label1.Visible = true;
            Label1.Text = "* 請先挑選檔案才能轉回 GridView !!!";
            FileUpload1.Visible = true;
            btnToGridView.Visible = true;
            btnToExcel.Visible = true;
            btnToSQL.Visible = true;
        }
    }
    protected void btnOpenClose_Click(object sender, EventArgs e)
    {
        if (countClick % 2 == 0)
        {
            FileUpload1.Visible = true;
            btnToGridView.Visible = true;
            btnToExcel.Visible = true;
            btnToSQL.Visible = true;
            btnSearch.Visible = true;
        }
        else
        {
            FileUpload1.Visible = false;
            btnToGridView.Visible = false;
            btnToExcel.Visible = false;
            btnToSQL.Visible = false;
            btnSearch.Visible = false;
        }
        countClick++;
    }
    private string getSelectSql()
    {
        string sql = "SELECT * FROM Customer WHERE 1=1 ";
        if (!string.IsNullOrEmpty(txtIdStart.Text) && !string.IsNullOrEmpty(txtIdEnd.Text))
            sql += " AND cId>=" + txtIdStart.Text + " AND cId<=" + txtIdEnd.Text;
        if (!string.IsNullOrEmpty(txtName.Text))
            sql += " AND cName LIKE '%" + txtName.Text + "%' ";
        if (!string.IsNullOrEmpty(txtAddress.Text))
            sql += " AND cAddress LIKE '%" + txtAddress.Text + "%' ";
        if (!string.IsNullOrEmpty(txtPhone.Text))
            sql += " AND cPhone LIKE '%" + txtPhone.Text + "%' ";
        if (!string.IsNullOrEmpty(txtEmail.Text))
            sql += " AND cEmail LIKE '%" + txtEmail.Text + "%' ";
        return sql;
    }
    protected void btnMultiSearch_Click(object sender, EventArgs e)
    {
        SqlDataSource sds = new SqlDataSource();
        sds.ConnectionString = SqlDataSource1.ConnectionString;
        sds.SelectCommand = getSelectSql();
        GridView1.DataSourceID = null;
        GridView1.DataSource = sds.Select(DataSourceSelectArguments.Empty);
        GridView1.DataBind();

        FileUpload1.Visible = true;
        btnToGridView.Visible = true;
        btnToExcel.Visible = true;
        btnToSQL.Visible = true;
        btnSearch.Visible = true;

        lblId.Visible = true;
        lblName.Visible = true;
        lblPhone.Visible = true;
        lblEmail.Visible = true;
        lblAddress.Visible = true;
        lblTo.Visible = true;
        txtIdEnd.Visible = true;
        txtIdStart.Visible = true;
        txtName.Visible = true;
        txtPhone.Visible = true;
        txtEmail.Visible = true;
        txtAddress.Visible = true;
        btnMultiSearch.Visible = true;
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        lblId.Visible = true;
        lblName.Visible = true;
        lblPhone.Visible = true;
        lblEmail.Visible = true;
        lblAddress.Visible = true;
        lblTo.Visible = true;
        txtIdEnd.Visible = true;
        txtIdStart.Visible = true;
        txtName.Visible = true;
        txtPhone.Visible = true;
        txtEmail.Visible = true;
        txtAddress.Visible = true;
        btnMultiSearch.Visible = true;
    }
    protected void lbtnOrders_Click(object sender, EventArgs e)
    {
        int i = GridView1.SelectedIndex;
        string s1 = null;
        //Session["ID"] = GridView1.Rows[i].Cells[1].FindControl("btnToWordContent");
        
        //lblT.Text = i.ToString();

        //s1 = ListView1.SelectedValue.ToString();
    
        lblT.Text = i.ToString();
    }   
    protected void ListView1_ItemCanceling(object sender, ListViewCancelEventArgs e)
    {

    }
    protected void ListView1_ItemDeleting(object sender, ListViewDeleteEventArgs e)
    {

    }
    protected void ListView1_ItemEditing(object sender, ListViewEditEventArgs e)
    {

    }
    protected void ListView1_ItemInserting(object sender, ListViewInsertEventArgs e)
    {

    }
    protected void ListView1_ItemUpdating(object sender, ListViewUpdateEventArgs e)
    {

    }
    protected void ListView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}