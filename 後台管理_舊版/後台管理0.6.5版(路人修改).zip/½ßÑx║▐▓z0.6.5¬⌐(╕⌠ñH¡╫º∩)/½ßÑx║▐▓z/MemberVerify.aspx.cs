﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class 後台管理_MemberVerify : System.Web.UI.Page
{
    SqlConnectionStringBuilder scsb;
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    public void btnChangeBool_click(object sender,EventArgs e) {
        scsb = new SqlConnectionStringBuilder();
        scsb.DataSource = "CR4-14\\MSSQLSERVER2013";
        scsb.InitialCatalog = "DBiii3rd";
        scsb.IntegratedSecurity = true;

        SqlConnection conn = new SqlConnection(scsb.ConnectionString);
        conn.Open();
        SqlCommand cmd = new SqlCommand("UpDate Customer set bool = 'false' where cId = '" + ((Button)sender).ToolTip + "'", conn);
        cmd.ExecuteNonQuery();
        conn.Close();

        Response.Redirect("../後台管理/MemberVerify.aspx");
    }

    public void TableMode(object sender,EventArgs e) {
        GroupCustomerVerify.Visible = true;
        GroupModeChange.Visible = false;
    }
    public void ChangeMode(object sender,EventArgs e)
    {
        GroupCustomerVerify.Visible = false;
        GroupModeChange.Visible = true;
    }



    protected void ListView1_SelectedIndexChanging(object sender, ListViewSelectEventArgs e)
    {

    }

}