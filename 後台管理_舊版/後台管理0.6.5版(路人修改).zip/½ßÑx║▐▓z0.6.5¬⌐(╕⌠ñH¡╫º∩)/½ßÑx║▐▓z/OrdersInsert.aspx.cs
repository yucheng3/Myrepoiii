﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class 後台管理_OrdersInsert : System.Web.UI.Page
{
    int count = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMessage1.Visible = false;
        lblMessage2.Visible = false;        
    }
    protected void FormView1_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {
        count++;
        Session["Count"] = Convert.ToInt32(Session["Count"]) + count;
        
        FormView1.Visible = false;
        if (Convert.ToInt32(Session["Count"]) == 2)
        {
            Response.Redirect("Orders.aspx");
        }
        else
        {
            lblMessage1.Visible = true;
            lblMessage1.Text = "訊息：訂單主表已新增，請繼續填寫明細表！";
        }
    }
    protected void FormView2_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {
        count++;
        Session["Count"] = Convert.ToInt32(Session["Count"]) + count;

        FormView2.Visible = false;
        if (Convert.ToInt32(Session["Count"]) == 2)
        {
            Response.Redirect("Orders.aspx");
        }
        else
        {
            lblMessage2.Visible = true;
            lblMessage2.Text = "訊息：訂單主表尚未填寫完！";
        }
    }
    protected void FormView1_ItemInserting(object sender, FormViewInsertEventArgs e)
    {
        if (string.IsNullOrEmpty(e.Values["cId"].ToString()))
        {
            lblMessage1.Visible = true;
            lblMessage1.Text = "注意：會員編號是必填欄位！";
            e.Cancel = true;
        }
    }
    protected void FormView2_ItemInserting(object sender, FormViewInsertEventArgs e)
    {
        if (string.IsNullOrEmpty(e.Values["oId"].ToString()))
        {
            lblMessage2.Visible = true;
            lblMessage2.Text = "注意：訂單編號是必填欄位！";
            e.Cancel = true;
        }
        if (string.IsNullOrEmpty(e.Values["itemNo"].ToString()))
        {
            lblMessage2.Visible = true;
            lblMessage2.Text = "注意：項目編號是必填欄位！";
            e.Cancel = true;
        }
        if (string.IsNullOrEmpty(e.Values["pId"].ToString()))
        {
            lblMessage2.Visible = true;
            lblMessage2.Text = "注意：產品編號是必填欄位！";
            e.Cancel = true;
        }
    }
}