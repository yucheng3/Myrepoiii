﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using NPOI.HSSF.UserModel;
using NPOI.HPSF;
using NPOI.HSSF;
using NPOI.POIFS.FileSystem;
using NPOI.SS.UserModel;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class 後台管理_Member : System.Web.UI.Page
{
    SqlConnectionStringBuilder scsb;      
    
    protected void Page_Load(object sender, EventArgs e)
    {
        DataLibDLL dataLib = new DataLibDLL();
        //SqlDataSource1.ConnectionString = dataLib.Conn_String();
        //SqlDataSource2.ConnectionString = dataLib.Conn_String();
        //SqlDataSource3.ConnectionString = dataLib.Conn_String();


        if (IsPostBack)
        {
            SourceDesignationCustomer.SelectCommand = "Select * From Customer Where cName = '" + (string)Session["Select"] + "'";
            SelectCustomerOrder.SelectCommand = "Select * From CustomerDetails Where CustomerName = '" + (string)Session["Select"] + "'";
            SourceCustomerProduct.SelectCommand = "SELECT cd.userAccount , pro.*, cp.CustomerID, cp.ProductID, cp.TotalProduct FROM ([Products] pro inner join [CustomerProducts] cp on pro.pId=cp.ProductID) inner join [CustomerDetails] cd on cp.CustomerID=cd.Id Where cd.userAccount = '" + (string)Session["Join"] + "'";
        }
        //if(Request.QueryString["customer"] != null){
        //    sqlDataQueryString(Request.QueryString["customer"]);            
        //}

    }    
    public override void VerifyRenderingInServerForm(Control control)
    {
        // 解決例外處理'GridView' 的控制項 'GridView' 必須置於有 runat=server 的表單標記之中
    }

    //150616換人尻
    //private List<string> dateTemp = new List<string>(); //就只是暫存
    public void VisibleFalse_click(object sender,EventArgs e) {
        for (int i = 0; i < ListView1.Items.Count; i++)
        {
            ListView1.Items[i].FindControl("Item_td_address").Visible = false;
            ListView1.Items[i].FindControl("Item_td_phone").Visible = false;
            ListView1.Items[i].FindControl("Item_td_email").Visible = false;

            //dateTemp.Add(((Label)ListView1.Items[i].FindControl("CreatedDateLabel")).Text);
            ((Label)ListView1.Items[i].FindControl("CreatedDateLabel")).Text = Convert.ToDateTime(((Label)ListView1.Items[i].FindControl("CreatedDateLabel")).Text).ToString("yy-MM-dd");
        }
        ListView1.FindControl("layout_th_address").Visible = false;
        ListView1.FindControl("layout_th_phone").Visible = false;
        ListView1.FindControl("layout_th_email").Visible = false;
    }
    public void VisibleTrue_click(object sender, EventArgs e)
    {
        for (int i = 0; i < ListView1.Items.Count; i++)
        {
            ListView1.Items[i].FindControl("Item_td_address").Visible = true;
            ListView1.Items[i].FindControl("Item_td_phone").Visible = true;
            ListView1.Items[i].FindControl("Item_td_email").Visible = true;
            //((Label)ListView1.Items[i].FindControl("CreatedDateLabel")).Text;
        }
        ListView1.FindControl("layout_th_address").Visible = true;
        ListView1.FindControl("layout_th_phone").Visible = true;
        ListView1.FindControl("layout_th_email").Visible = true;
    }

    //150616客戶資料編輯
    public void sqlData_click(object sender,EventArgs e) {   ////點選後啟用狀態     

        string userAccount = ((Button)sender).CommandName;
        Session["Join"] = userAccount;
        Session["Select"] = ((Button)sender).ToolTip;
        //labelTest.Text = ((Label)ListView1.Items[i].FindControl("cName")).Text; ;
        SourceDesignationCustomer.SelectCommand = "Select * From Customer Where cName = '" + ((Button)sender).ToolTip + "'";        
        ListViewDesignationCustomer.DataSourceID = "SourceDesignationCustomer";
        ListViewDesignationCustomer.DataBind();
        //GroupDesignationCustomer_h1.InnerText = "姓名 : " + ((Button)sender).ToolTip;

        SelectCustomerOrder.SelectCommand = "Select * From CustomerDetails Where CustomerName = '" + ((Button)sender).ToolTip + "'";
        ListViewSelectCustomerOrder.DataSourceID = "SelectCustomerOrder";
        ListViewSelectCustomerOrder.DataBind();

        SourceCustomerProduct.SelectCommand = "SELECT cd.userAccount , pro.*, cp.CustomerID, cp.ProductID, cp.TotalProduct FROM ([Products] pro inner join [CustomerProducts] cp on pro.pId=cp.ProductID) inner join [CustomerDetails] cd on cp.CustomerID=cd.Id Where cd.userAccount = '" + userAccount + "'";
        ListView4.DataSourceID = "SourceCustomerProduct";
        ListView4.DataBind();
        //Group4_h3_orderCount.InnerText = "共" + ListView4.DataPa + "筆訂單";        
        Group4_h3_orderCount.InnerText = "";
        Group4_h3_orderCount.InnerText = ((DataPager)ListView4.FindControl("DataPager1")).Controls.Count + "筆訂單";

        GroupSourceCustomer.Visible = false;//登入會員資料最初顯示的Group
        GroupDesignationCustomer.Visible = true;//前端預設false
        GroupSelectCustomerOrder.Visible = true;//前端預設false
        GroupCustomerProductOrder.Visible = true;//前端預設false(join 2次)
    }
    //重下(在pageLoad和下面這個)
    protected void ListViewDesignationCustomer_ItemUpdated(object sender, ListViewUpdatedEventArgs e)
    {
        SourceDesignationCustomer.SelectCommand = "Select * From Customer Where cName = '" + (string)Session["Select"] + "'";
        //SourceDesignationCustomer.UpdateCommand = "UPDATE [Customer] SET [cName] = @cName, [cAddress] = @cAddress, [cPhone] = @cPhone, [cEmail] = @cEmail, [cAccount] = @cAccount, [cPassword] = @cPassword, [CreatedDate] = @CreatedDate, [bool] = @bool Where [cName] = " + (string)Session["Select"] + "";
    }
    //接收OrderQueryString_150623取消
    private void sqlDataQueryString(string queryString) {
        Session["Select"] = queryString;
        SourceDesignationCustomer.SelectCommand = "Select * From Customer Where cName = '" + queryString + "'" 
            + " AND bool IS NOT NULL";
        ListViewDesignationCustomer.DataSourceID = "SourceDesignationCustomer";
        ListViewDesignationCustomer.DataBind();

        SelectCustomerOrder.SelectCommand = "Select * From CustomerDetails Where CustomerName = '" + queryString + "'";
        ListViewSelectCustomerOrder.DataSourceID = "SelectCustomerOrder";
        ListViewSelectCustomerOrder.DataBind();

        GroupSourceCustomer.Visible = false;//登入會員資料最初顯示的Group
        GroupDesignationCustomer.Visible = true;//前端預設false
        GroupSelectCustomerOrder.Visible = true;//前端預設false
    }
    public void btnToMember(object sender,EventArgs e) {
        Response.Redirect("../後台管理/Member.aspx");
    }

    //150617撿現成得~~~來改
    private string DDlSelectSqlString()
    {
        string sql = "SELECT * FROM Customer WHERE 1=1 ";
        if (!string.IsNullOrEmpty(DDLTextBox.Text))
            sql += " AND " + DropDownList.SelectedValue + " LIKE '%" + DDLTextBox.Text + "%' ";      
        //條件
        sql += " AND bool IS NOT NULL";
        return sql;
    }
    public void DDL_click(object sender, EventArgs e)
    {
        GroupSourceCustomer.Visible = true;//登入會員資料最初顯示的Group
        GroupDesignationCustomer.Visible = false;//前端預設false
        GroupSelectCustomerOrder.Visible = false;//前端預設false

        SourceCustomer.SelectCommand = DDlSelectSqlString();
        ListView1.DataSourceID = "SourceCustomer";
        ListView1.DataBind();
    }

    //150624抓高手修改__ListView匯出Execl
    protected void btnToExcel_Click(object sender, EventArgs e)
    {
        //學高手的150624_把listView會顯示在execl上的欄位全部Visible掉
        ListView1.FindControl("layout_stoolRow").Visible = false;
        ListView1.FindControl("layout_div_dataPage1").Visible = false;
        ListView1.FindControl("layout_table_tr_th_operating").Visible = false;
        //ListView1.FindControl("layout_table_tr").Visible = false;
        //將ListView1的第一欄隱藏，轉Excel才不會有該欄  
        for (int i = 0; i < ListView1.Items.Count;i++ ){
            ((HtmlTableCell)ListView1.Items[i].FindControl("ggg")).Visible = false; 
        }
        //上面listView1
        Response.ClearContent();
        Response.Write("<meta http-equiv=Content-Type content=text/html;charset=utf-8>");
        string excelFileName = "MemberData.xls";
        Response.AddHeader("content-disposition", "attachment;filename=" + Server.UrlEncode(excelFileName));
        Response.ContentType = "application/excel";
        System.IO.StringWriter stringWrite = new System.IO.StringWriter();
        System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);
        ListView1.RenderControl(htmlWrite);
        Response.Write("<style type=text/css>");
        Response.Write("td{mso-number-format:\"\\@\";}"); //將欄位格式改成文字
        Response.Write("</style>");
        Response.Write(stringWrite.ToString());
        Response.End();
    }    
    
    //150624Execl上傳轉換成ListView顯示
    protected void btnToGridView_Click(object sender, EventArgs e)
    {
        string savePath = Server.MapPath("~/Excel檔/");

        if (FileUpload1.HasFile)
        {
            string filename = FileUpload1.FileName;
            string extension = Path.GetExtension(filename).ToLower(); // 取得副檔名，並且ToLower()轉小寫

            savePath += filename;
            FileUpload1.SaveAs(savePath);

            if (extension.Equals(".xls")) // 檢查副檔名是否正確
            {
                try
                {
                    HSSFWorkbook myWorkbook = new HSSFWorkbook(FileUpload1.FileContent);
                    ISheet mySheet = myWorkbook.GetSheetAt(0);
                    DataTable myDT = new DataTable();

                    // 將mysheet工作表的第一列存入DATATABLE
                    HSSFRow headerRow = mySheet.GetRow(0) as HSSFRow;
                    for (int i = headerRow.FirstCellNum; i < headerRow.LastCellNum; i++)
                    {
                        if (headerRow.GetCell(i) != null)
                        {
                            DataColumn myColumn = new DataColumn(headerRow.GetCell(i).StringCellValue);
                            myDT.Columns.Add(myColumn);
                        }
                    }

                    // 將mysheet第一列後的資料存入DATATABLE
                    for (int i = mySheet.FirstRowNum + 1; i <= mySheet.LastRowNum; i++)
                    {
                        HSSFRow row = mySheet.GetRow(i) as HSSFRow;
                        DataRow myRow = myDT.NewRow();
                        for (int j = row.FirstCellNum; j < row.LastCellNum; j++)
                        {
                            if (row.GetCell(j) != null)
                            {
                                myRow[j] = row.GetCell(j).ToString();
                            }
                        }
                        myDT.Rows.Add(myRow);
                    }

                    myWorkbook = null;
                    mySheet = null;
                    DataView myView = new DataView(myDT);
                    GridViewSourceCustomer.DataSourceID = null;
                    GridViewSourceCustomer.DataSource = myDT;
                    GridViewSourceCustomer.AllowSorting = true;  //GridView才有
                    GridViewSourceCustomer.DataBind();

                    //lblMessage.Visible = true;
                    lblMessage.Text = "GridView 上傳成功！";
                    //FileUpload1.Visible = true;
                    //btnToGridView.Visible = true;
                    //btnToExcel.Visible = true;
                    //btnToSQL.Visible = true;
                    //btnSearch.Visible = true;

                    //GridViewToSQL!!!!!
                    GridViewToSQL();
                }
                catch (Exception ex)
                {
                    Response.Write("  Error Message : " + ex.ToString());
                }
            }
            else
            {
                //lblMessage.Visible = true;
                lblMessage.Text = "請放上正確副檔名(.xls)的檔案！";
            }
        }
        else
        {
            //lblMessage.Visible = true;
            lblMessage.Text = "請先挑選檔案才能轉回 GridView !";
            //FileUpload1.Visible = true;
            //btnToGridView.Visible = true;
            //btnToExcel.Visible = true;
            //btnToSQL.Visible = true;
            //btnSearch.Visible = true;
        }
    }


    //150624_GridView轉SQL
    protected void GridViewToSQL()
    {
        scsb = new SqlConnectionStringBuilder();
        DataLibDLL dataLib = new DataLibDLL();
        scsb.ConnectionString = dataLib.Conn_String();
        scsb.IntegratedSecurity = true;

        SqlConnection con = new SqlConnection(scsb.ToString());
        con.Open();
        // 查詢資料庫中最小cId及最大cId
        SqlCommand cmd2 = new SqlCommand(@"SELECT min(cId) FROM Customer", con);
        SqlCommand cmd3 = new SqlCommand(@"SELECT max(cId) FROM Customer", con);
        int cIdMax = Convert.ToInt32(cmd3.ExecuteScalar());
        int[] count = new int[GridViewSourceCustomer.Rows.Count]; // 宣告count陣列來存放相同cId的
        // 資料庫資料的cId和匯入資料的cId相同，做Update
        for (int cIdMin = Convert.ToInt32(cmd2.ExecuteScalar()); cIdMin <= cIdMax; cIdMin++)
        {
            for (int i = 0; i < GridViewSourceCustomer.Rows.Count; i++)
            {
                if (cIdMin == Convert.ToInt32(GridViewSourceCustomer.Rows[i].Cells[0].Text))
                {
                    SqlCommand cmd = new SqlCommand(@"Update Customer set cName=@NewName,cAddress=@NewAddress," +
                        "cPhone=@NewPhone,cEmail=@NewEmail,cAccount=@NewAccount Where cId=@Id", con);

                    cmd.Parameters.AddWithValue("@Id", GridViewSourceCustomer.Rows[i].Cells[0].Text);
                    cmd.Parameters.AddWithValue("@NewName", GridViewSourceCustomer.Rows[i].Cells[1].Text);
                    cmd.Parameters.AddWithValue("@NewAddress", GridViewSourceCustomer.Rows[i].Cells[2].Text);
                    cmd.Parameters.AddWithValue("@NewPhone", GridViewSourceCustomer.Rows[i].Cells[3].Text);
                    cmd.Parameters.AddWithValue("@NewEmail", GridViewSourceCustomer.Rows[i].Cells[4].Text);
                    cmd.Parameters.AddWithValue("@NewAccount", GridViewSourceCustomer.Rows[i].Cells[5].Text);

                    int rows = cmd.ExecuteNonQuery();
                    count[i] = Convert.ToInt32(GridViewSourceCustomer.Rows[i].Cells[0].Text);
                }
            }
        }

        int flag = 0;
        // 資料庫資料的cId和匯入資料的cId不同，做Insert        
        for (int i = 0; i < GridViewSourceCustomer.Rows.Count; i++)
        {
            for (int j = 0; j < GridViewSourceCustomer.Rows.Count; j++)
            {   // 判斷該筆資料是否已Update了
                if (Convert.ToInt32(GridViewSourceCustomer.Rows[i].Cells[0].Text) == count[j])
                {
                    flag = 1; // 該筆資料有Update
                }
            }
            if (flag != 1) // 該筆資料沒有Update
            {   // 因cId有設定識別規格，所以要設IDENTITY_INSERT=ON 且指定資料行名稱(cId,cName,cAddress,cPhone,cEmail,cAccount,cPassword)
                SqlCommand cmd = new SqlCommand(@"SET IDENTITY_INSERT Customer ON Insert into " +
                    "Customer (cId,cName,cAddress,cPhone,cEmail,cAccount) Values(@cId,@cName,@cAddress,@cPhone,@cEmail,@cAccount)", con);

                cmd.Parameters.AddWithValue("@cId", GridViewSourceCustomer.Rows[i].Cells[0].Text);
                cmd.Parameters.AddWithValue("@cName", GridViewSourceCustomer.Rows[i].Cells[1].Text);
                cmd.Parameters.AddWithValue("@cAddress", GridViewSourceCustomer.Rows[i].Cells[2].Text);
                cmd.Parameters.AddWithValue("@cPhone", GridViewSourceCustomer.Rows[i].Cells[3].Text);
                cmd.Parameters.AddWithValue("@cEmail", GridViewSourceCustomer.Rows[i].Cells[4].Text);
                cmd.Parameters.AddWithValue("@cAccount", GridViewSourceCustomer.Rows[i].Cells[5].Text);

                int rows = cmd.ExecuteNonQuery();
            }
            else { flag = 0; }
        }

        con.Close();
        con.Dispose();
        //lblMessage.Visible = true;
        lblMessage.Text += "\n 匯入SQL成功!";
        //FileUpload1.Visible = true;
        //btnToGridView.Visible = true;
        //btnToExcel.Visible = true;
        //btnToSQL.Visible = true;
        //btnSearch.Visible = true;

        //150624自己增加
        ListView1.DataSourceID = "SourceCustomer";
        ListView1.DataBind();
    }






    //*520分水嶺____阿扁不能亡!__豪哥的傑作*/



    //protected void btnSearch_Click(object sender, EventArgs e)
    //{
    //    if (GridView1.Visible == true)
    //    {
    //        //btnSearch.Visible = false;
    //        divSearch.Visible = true;
    //    }
    //    else if (GridView2.Visible == true)
    //    {
    //        //btnSearch.Visible = false;

    //    }
    //    else if (GridView3.Visible == true)
    //    {
    //        //btnSearch.Visible = false;
    //        divSearch3.Visible = true;
    //    }
    //}    
    //private string getSelectSql()
    //{
    //    string sql = "SELECT * FROM Customer WHERE 1=1 ";
    //    if (!string.IsNullOrEmpty(txtIdStart.Text) && !string.IsNullOrEmpty(txtIdEnd.Text))
    //        sql += " AND cId>=" + txtIdStart.Text + " AND cId<=" + txtIdEnd.Text;
    //    if (!string.IsNullOrEmpty(txtName.Text))
    //        sql += " AND cName LIKE '%" + txtName.Text + "%' ";
    //    if (!string.IsNullOrEmpty(txtAddress.Text))
    //        sql += " AND cAddress LIKE '%" + txtAddress.Text + "%' ";
    //    if (!string.IsNullOrEmpty(txtPhone.Text))
    //        sql += " AND cPhone LIKE '%" + txtPhone.Text + "%' ";
    //    if (!string.IsNullOrEmpty(txtEmail.Text))
    //        sql += " AND cEmail LIKE '%" + txtEmail.Text + "%' ";
    //    return sql;
    //}    
    //protected void btnMultiSearch_Click(object sender, EventArgs e)
    //{              
    //    scsb = new SqlConnectionStringBuilder();
    //    DataLibDLL dataLib = new DataLibDLL();
    //    scsb.ConnectionString = dataLib.Conn_String();
    //    SqlDataSource1.SelectCommand = getSelectSql();
    //    GridView1.DataBind();
        
    //    divSearch.Visible = true;
    //}
    //protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    //{
    //    this.btnMultiSearch_Click(sender, e);
    //    divSearch.Visible = false;
    //    //btnSearch.Visible = true;
    //}
    //protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    //{
    //    this.btnMultiSearch_Click(sender, e);
    //    divSearch.Visible = false;
    //    //btnSearch.Visible = true;
    //}
    //protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    //{
    //    this.btnMultiSearch_Click(sender, e);
    //    divSearch.Visible = false;
    //    //btnSearch.Visible = true;
    //}
    //protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    //{
    //    this.btnMultiSearch_Click(sender, e);
    //    divSearch.Visible = false;
    //    //btnSearch.Visible = true;
    //}

    //private string getSelectSql2()
    //{
    //    string sql = "SELECT cp.*, cd.CustomerName FROM [CustomerProducts] cp inner join [CustomerDetails] cd on cp.CustomerID=cd.Id WHERE 1=1 ";
    //    if (!string.IsNullOrEmpty(txtCustomerIDStart.Text) && !string.IsNullOrEmpty(txtCustomerIDEnd.Text))
    //        sql += " AND CustomerID>=" + txtCustomerIDStart.Text + " AND CustomerID<=" + txtCustomerIDEnd.Text;
    //    if (!string.IsNullOrEmpty(txtCustomerName.Text))
    //        sql += " AND CustomerName LIKE '%" + txtCustomerName.Text + "%' ";
    //    if (!string.IsNullOrEmpty(txtProductID.Text))
    //        sql += " AND ProductID LIKE '%" + txtProductID.Text + "%' ";
    //    if (!string.IsNullOrEmpty(txtTotalProduct.Text))
    //        sql += " AND TotalProduct LIKE '%" + txtTotalProduct.Text + "%' ";     
    //    return sql;
    //}

    //protected void btnMultiSearch2_Click(object sender, EventArgs e)
    //{        
    //    scsb = new SqlConnectionStringBuilder();       
    //    DataLibDLL dataLib = new DataLibDLL();
    //    scsb.ConnectionString = dataLib.Conn_String();
    //    //SqlDataSource2.SelectCommand = getSelectSql2();
    //    GridView2.DataBind();
    //}
    //protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    //{      
    //    LinkButton lbtnOrders = (LinkButton)GridView1.SelectedRow.Cells[0].FindControl("lbtnOrders");
    //    lblTitle.Text = "訂單主檔";
    //    string sql = "SELECT cp.*, cd.CustomerName, cd.userAccount FROM [CustomerProducts] cp inner join [CustomerDetails] cd on cp.CustomerID=cd.Id ";
    //    sql += "WHERE cd.userAccount='" + lbtnOrders.ToolTip + "'";

    //    SqlDataSource sds = new SqlDataSource();
    //    sds.ConnectionString = SqlDataSource1.ConnectionString;
    //    SqlDataSource2.SelectCommand = sql;        
    //    GridView2.DataBind();
    //    GridView2.Visible = true;
    //    lbtnMore.Visible = false;
    //    GridView1.Visible = false;
    //    divSearch.Visible = false;
    //}
    //protected void GridView2_RowEditing(object sender, GridViewEditEventArgs e)
    //{
    //    this.GridView1_SelectedIndexChanged(sender, e);
    //}
    //protected void GridView2_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    //{
    //    this.GridView1_SelectedIndexChanged(sender, e);
    //}
    //protected void GridView2_RowDeleting(object sender, GridViewDeleteEventArgs e)
    //{
    //    this.GridView1_SelectedIndexChanged(sender, e);
    //}
    //protected void GridView2_RowUpdating(object sender, GridViewUpdateEventArgs e)
    //{
    //    this.GridView1_SelectedIndexChanged(sender, e);
    //}
    //private string getSelectSql3()
    //{
    //    string sql = "SELECT * FROM [CustomerDetails] WHERE 1=1 ";
    //    if (!string.IsNullOrEmpty(txtCustomerIDStart2.Text) && !string.IsNullOrEmpty(txtCustomerIDEnd2.Text))
    //        sql += " AND Id>=" + txtCustomerIDStart2.Text + " AND Id<=" + txtCustomerIDEnd2.Text;
    //    if (!string.IsNullOrEmpty(txtCustomerName2.Text))
    //        sql += " AND CustomerName LIKE '%" + txtCustomerName2.Text + "%' ";
    //    if (!string.IsNullOrEmpty(txtCustomerEmail.Text))
    //        sql += " AND CustomerEmailID LIKE '%" + txtCustomerEmail.Text + "%' ";
    //    if (!string.IsNullOrEmpty(txtCustomerPhone.Text))
    //        sql += " AND CustomerPhoneNo LIKE '%" + txtCustomerPhone.Text + "%' ";
    //    if (!string.IsNullOrEmpty(txtCustomerAddress.Text))
    //        sql += " AND CustomerAddress LIKE '%" + txtCustomerAddress.Text + "%' ";
    //    if (!string.IsNullOrEmpty(txtTotalProduct2.Text))
    //        sql += " AND TotalProducts LIKE '%" + txtTotalProduct2.Text + "%' ";
    //    if (!string.IsNullOrEmpty(txtTotalPrice.Text))
    //        sql += " AND TotalPrice LIKE '%" + txtTotalPrice.Text + "%' ";
    //    return sql;
    //}
    //protected void btnMultiSearch3_Click(object sender, EventArgs e)
    //{
    //    scsb = new SqlConnectionStringBuilder();       
    //    DataLibDLL dataLib = new DataLibDLL();
    //    scsb.ConnectionString = dataLib.Conn_String();
    //    SqlDataSource3.SelectCommand = getSelectSql3();
    //    GridView3.DataBind();

    //}
    //protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    LinkButton lbtnOrderDetail = (LinkButton)GridView2.SelectedRow.Cells[0].FindControl("lbtnOrderDetail");
    //    //lblTitle.Text = "訂單明細檔";
    //    string sql = "SELECT * FROM CustomerDetails ";
    //    sql += "WHERE Id=" + lbtnOrderDetail.ToolTip;

    //    SqlDataSource sds = new SqlDataSource();
    //    sds.ConnectionString = SqlDataSource1.ConnectionString;
    //    SqlDataSource3.SelectCommand = sql;
    //    GridView3.DataBind();
    //    lbtnMore2.Visible = true;
    //    GridView3.Visible = true;
    //    GridView2.Visible = false;
  
    //}
    //protected void GridView3_RowEditing(object sender, GridViewEditEventArgs e)
    //{
    //    this.GridView2_SelectedIndexChanged(sender, e);
    //}
    //protected void GridView3_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    //{
    //    this.GridView2_SelectedIndexChanged(sender, e);
    //}
    //protected void GridView3_RowDeleting(object sender, GridViewDeleteEventArgs e)
    //{
    //    this.GridView2_SelectedIndexChanged(sender, e);
    //}
    //protected void GridView3_RowUpdating(object sender, GridViewUpdateEventArgs e)
    //{
    //    this.GridView2_SelectedIndexChanged(sender, e);
    //}
    //protected void lbtnMore_Click(object sender, EventArgs e)
    //{   
    //    this.btnMultiSearch_Click(sender, e);
    //    if (lbtnMore.Text == "+ 更多")
    //    {
    //        GridView1.Columns[7].Visible = true;
    //        lbtnMore.Text = "- 收合";
    //    }
    //    else
    //    {
    //        GridView1.Columns[7].Visible = false;
    //        lbtnMore.Text = "+ 更多";
    //    }        
    //}
    //protected void lbtnMore2_Click(object sender, EventArgs e)
    //{
    //    this.btnMultiSearch3_Click(sender, e);
    //    if (lbtnMore2.Text == "+ 更多")
    //    {
             
    //        GridView3.Columns[8].Visible = true;
    //        GridView3.Columns[9].Visible = true;
    //        GridView3.Columns[10].Visible = true;
    //        lbtnMore2.Text = "- 收合";
    //    }
    //    else
    //    {
    //        GridView3.Columns[8].Visible = false;
    //        GridView3.Columns[9].Visible = false;
    //        GridView3.Columns[10].Visible = false;
    //        lbtnMore2.Text = "+ 更多";
    //    }       
    //}


}