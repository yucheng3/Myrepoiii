﻿using NPOI.HPSF;
using NPOI.HSSF;
using NPOI.HSSF.UserModel;
using NPOI.POIFS.FileSystem;
using NPOI.SS.UserModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Data;
using System.IO;

public partial class products_item : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            FillGridView();
        }
    }
    private void FillGridView()
    {

        GridView1.DataSource = Product_search();
        GridView1.DataBind();
    }
    DataSet ds = new DataSet();
    DataTable dt = new DataTable();
    private DataSet Product_search()
    {
        DataLibBLL p = new DataLibBLL();
        p.Product_Id = (txtsearch0.Text.ToString().Trim() == "" ? -1 : Convert.ToInt32(txtsearch0.Text.Trim()));
        p.Product_Name = (txtsearch1.Text.ToString().Trim() == "" ? "" : txtsearch1.Text.ToString().Trim());
        p.Product_Price = (txtsearch2.Text.ToString().Trim() == "" ? -1 : Convert.ToInt32(txtsearch2.Text.Trim()));
        p.Product_Price_high = (txtsearch3.Text.ToString().Trim() == "" ? -1 : Convert.ToInt32(txtsearch3.Text.Trim()));
        p.Factory_Name = (txtsearch4.Text.ToString().Trim() == "" ? "" : txtsearch4.Text.ToString().Trim());
        DataLibDLL obj = new DataLibDLL();
        ds = obj.Select_Product_search(p);
        obj = null;
        return ds;
    }

    protected void btnsearch_Click(object sender, EventArgs e)
    {
        if (txtsearch2.Text.ToString().Trim() != "" && txtsearch3.Text.ToString().Trim() != "")
        {
            int price_low = Convert.ToInt32(txtsearch2.Text.Trim());
            int price_high = Convert.ToInt32(txtsearch3.Text.Trim());
            if (price_low > price_high)
            {
                //顯示產品價格輸入錯誤訊息
                GridView1.Visible = false;
                lblwarm.Visible = true;
                lblwarm.Text = "請輸入正確的產品價格範圍！";
            }
            else if (price_low < price_high)
            {
                ds = Product_search();
                dt = ds.Tables["prd_search"];
                if (dt.Rows.Count > 0)
                {
                    //將資料記錄顯示在GridView1制項上
                    GridView1.Visible = true;
                    lblwarm.Visible = false;
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                }
                else
                {
                    //顯示查不到之訊息
                    GridView1.Visible = false;
                    lblwarm.Visible = true;
                    lblwarm.Text = "查無該項產品之資料記錄！";
                }
            }
        }
        else
        {
            ds = Product_search();
            dt = ds.Tables["prd_search"];
            if (dt.Rows.Count > 0)
            {
                //將資料記錄顯示在GridView1制項上
                GridView1.Visible = true;
                lblwarm.Visible = false;
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
            else
            {
                //顯示查不到之訊息
                GridView1.Visible = false;
                lblwarm.Visible = true;
                lblwarm.Text = "查無該項產品之資料記錄！";
            }
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        FillGridView();

    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        DataLibBLL p = new DataLibBLL();
        p.Product_Id = Convert.ToInt32(((Label)GridView1.Rows[e.RowIndex].FindControl("lblpid")).Text);
        DataLibDLL obj = new DataLibDLL();
        obj.Delete_Product(p.Product_Id);
        FillGridView();
        obj = null;
    }
    protected void GridView1_Sorting(object sender, GridViewSortEventArgs e)
    {
        string sortExp = e.SortExpression;
        string direction = "";
        if (SortDir == SortDirection.Ascending)
        {
            SortDir = SortDirection.Descending;
            direction = "DESC";
        }
        else
        {
            SortDir = SortDirection.Ascending;
            direction = "ASC";
        }
        ds = Product_search();
        dt = ds.Tables["prd_search"];
        dt.DefaultView.Sort = sortExp + " " + direction;
        GridView1.DataSource = dt;
        GridView1.DataBind();

    }
    public SortDirection SortDir 
    {
        get {
            if (ViewState["SortDir"] == null)
            { 
            ViewState["SortDir"] = SortDirection.Ascending;
            }
            return (SortDirection)ViewState["SortDir"];
        }
        set {
            ViewState["SortDir"] = value;
        }
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        //連結到products_insert.aspx，新增產品資料
        Response.Redirect("products_insert.aspx");
    }
    //輸出EXCEL
    protected void btnoutexcel_Click(object sender, EventArgs e)
    {
        ds = Product_search();
        dt = ds.Tables["prd_search"];
        ExportDataTableToExcel(dt);
    }
    public void ExportDataTableToExcel(DataTable pDataTable)
    {
        int tRowCount = pDataTable.Rows.Count;
        int tColumnCount = pDataTable.Columns.Count;

        Response.Expires = 0;
        Response.Clear();
        Response.Buffer = true;
        Response.Charset = "utf-8";
        Response.ContentEncoding = System.Text.Encoding.UTF8;

        Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        //'Excel 2003 : "application/vnd.ms-excel"
        //'Excel 2007 : "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        Response.AddHeader("Content-Disposition", string.Format("attachment; filename={0}","product.xls"));
        Response.Write("<meta http-equiv=Content-Type content=text/html;charset=utf-8>");
        Response.Write("<style type=text/css>");
        Response.Write("td{mso-number-format:\"\\@\";}"); //將所有欄位格式改為"文字"
        Response.Write("</style>");
        Response.Write("<Table borderColor=black border=1>");
        Response.Write("\n <TR>");
        //表頭
        for (int i = 0; i < tColumnCount; i++)
        {
            Response.Write("\n <TD align=\"center\" x:num>");
            Response.Write(pDataTable.Columns[i].ColumnName);
            Response.Write("\n </TD>");
        }
        Response.Write("\n </TR>");
        //表身
        for (int j = 0; j < tRowCount; j++)
        {
            Response.Write("\n <TR>");
            for (int k = 0; k < tColumnCount; k++)
            {
                Response.Write("\n <TD align=\"right\" x:num>");
                Response.Write(pDataTable.Rows[j][k].ToString());
                Response.Write("\n </TD>");
            }
            Response.Write("\n </TR>");
        }
        Response.Write("</Table>");
        Response.End();
    }
    protected void btninsert_excel_Click(object sender, EventArgs e)
    {
        lblwarm.Visible = false;
        lblwarm.Text = "";
        //是否允許上載
        bool fileAllow = false;
        string[] allowExtensions = { ".xls" };
        if ((FileUpload_prd_excel).HasFile)
        {
            //取得上載檔案之延伸檔名，並轉換成小寫字母
            string fileExtension = System.IO.Path.GetExtension((FileUpload_prd_excel).FileName).ToLower();
            //檢查延伸檔名是否符合限定類型
            for (int j = 0; j < allowExtensions.Length; j++)
            {
                if (fileExtension == allowExtensions[j])
                {
                    fileAllow = true;
                }
                else
                {
                    lblwarm.Visible = true;
                    lblwarm.Text = "檔案副檔名不符合限定類型";
                }
            }
            string savePath = Server.MapPath("~/Excel檔/");
            string filename = FileUpload_prd_excel.FileName;
            if (fileAllow)
            {
                savePath += filename;
                FileUpload_prd_excel.SaveAs(savePath);
                DataLibBLL p = new DataLibBLL();
                DataLibDLL obj = new DataLibDLL();
                try
                {
                    HSSFWorkbook myWorkbook = new HSSFWorkbook(FileUpload_prd_excel.FileContent);
                    ISheet mySheet = myWorkbook.GetSheetAt(0);
                    DataTable dt = new DataTable();

                    // 將mysheet工作表的第一列存入DATATABLE
                    HSSFRow headerRow = mySheet.GetRow(0) as HSSFRow;
                    for (int i = headerRow.FirstCellNum; i < headerRow.LastCellNum; i++)
                    {
                        if (headerRow.GetCell(i) != null)
                        {
                            DataColumn myColumn = new DataColumn(headerRow.GetCell(i).StringCellValue);
                            dt.Columns.Add(myColumn);
                        }
                    }

                    // 將mysheet第一列後的資料存入DATATABLE
                    for (int i = mySheet.FirstRowNum + 1; i <= mySheet.LastRowNum; i++)
                    {
                        HSSFRow row = mySheet.GetRow(i) as HSSFRow;
                        DataRow myRow = dt.NewRow();
                        for (int j = row.FirstCellNum; j < row.LastCellNum; j++)
                        {
                            if (row.GetCell(j) != null)
                            {
                                myRow[j] = row.GetCell(j).ToString();
                            }
                        }
                        dt.Rows.Add(myRow);
                    }
                    myWorkbook = null;
                    mySheet = null;

                    obj.GetConnection();
                    obj.TranBegin();
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        p.Product_Name = dt.Rows[i]["pName"].ToString();
                        p.Product_Price = Convert.ToInt32(dt.Rows[i]["pPrice"]);
                        p.Product_Introduction = dt.Rows[i]["pIntroduction"].ToString();
                        p.Product_Specification = dt.Rows[i]["pSpecification"].ToString();
                        p.Product_PhotoPath1 = dt.Rows[i]["pPhoto1"].ToString();
                        p.Product_PhotoPath2 = dt.Rows[i]["pPhoto2"].ToString();
                        p.Product_PhotoPath3 = dt.Rows[i]["pPhoto3"].ToString();
                        p.Factory_Id = Convert.ToInt32(dt.Rows[i]["fId"]);
                        obj.Insert_Product_Transaction(p);
                    }
                    obj.TranCommit();
                    obj.CloseConnection();
                    FillGridView();
                    obj = null;
                    //檢查是否有檔案有即刪除
                    if (File.Exists(savePath))
                    {
                        File.Delete(savePath);
                    }
                }
                catch (Exception)
                {
                    lblwarm.Visible = true;
                    lblwarm.Text = "EXCEL檔儲存到資料庫失敗!";
                    obj.TranRollback();
                    //檢查是否有檔案有即刪除
                    if (File.Exists(savePath))
                    {
                        File.Delete(savePath);
                    }
                }
            }
        }
        else
        {
            lblwarm.Visible = true;
            lblwarm.Text = "未選取EXCEL檔!";
        }
    }
    protected void btninsert_pics_Click(object sender, EventArgs e)
    {
        lblwarm.Visible = false;
        lblwarm.Text = "";
        string[] str = new string[4];
        //是否允許上載
        bool fileAllow = false;
        //設定允許上載的延伸檔名類型
        string[] allowExtensions = { ".jpg", ".gif", ".png" };

        //取得網站根目錄路徑
        string photopath = Server.MapPath("~/pics/");
        string PhotoGuid;
        string savePath;
        if (FileUpload_prd_pics.HasFile)
        {
            try
            {
                foreach (HttpPostedFile postedFile in FileUpload_prd_pics.PostedFiles)
                {
                    string fileExtension = System.IO.Path.GetExtension(postedFile.FileName).ToLower();
                    for (int j = 0; j < allowExtensions.Length; j++)
                    {
                        if (fileExtension == allowExtensions[j])
                        {
                            fileAllow = true;
                        }
                    }
                    if (fileAllow)
                    {
                        PhotoGuid = postedFile.FileName;
                        savePath = photopath + PhotoGuid;
                        postedFile.SaveAs(savePath);
                    }
                }
            }
            catch (Exception)
            {
                lblwarm.Visible = true;
                lblwarm.Text = "圖檔有問題請檢查!";
            }
        }
        else {
            lblwarm.Visible = true;
            lblwarm.Text = "未選取圖檔!";
        }
    }
}