﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class products_update : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            FillFormView_lastpid();
        }
    }
    private void FillFormView_lastpid()
    {
        DataLibDLL obj = new DataLibDLL();
        DataLibBLL p = new DataLibBLL();
        FormView1.DataSource = obj.Select_Product_lastpid();
        FormView1.DataBind();
        obj = null;
    }
    protected void FormView1_DataBound(object sender, EventArgs e)
    {
        DataLibDLL obj = new DataLibDLL();
        DataTable dtFacid = obj.Select_Factory_id();
        if (FormView1.CurrentMode == FormViewMode.Insert)
        {
            try
            {
                ((DropDownList)FormView1.FindControl("DropDownList2")).DataSource = dtFacid;
                ((DropDownList)FormView1.FindControl("DropDownList2")).DataTextField = dtFacid.Columns["fName"].ToString();
                ((DropDownList)FormView1.FindControl("DropDownList2")).DataValueField = dtFacid.Columns["fId"].ToString();
                ((DropDownList)FormView1.FindControl("DropDownList2")).DataBind();
                obj = null;
            }
            catch (Exception)
            { }
        }
    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        ((Label)FormView1.FindControl("lblfid2")).Text = ""; 
        try
        {
            ((Label)FormView1.Row.FindControl("lblfid1")).Text = (((DropDownList)FormView1.FindControl("DropDownList2")).SelectedValue).ToString();
        }
        catch (Exception)
        { }
    }
    protected void FormView1_ItemInserting(object sender, FormViewInsertEventArgs e)
    {
        string photopath = "~/pics/";
        string[] str = new string[4];

        //是否允許上載
        bool fileAllow = false;
        //設定允許上載的延伸檔名類型
        string[] allowExtensions = { ".jpg", ".gif", ".png" };

        //取得網站根目錄路徑
        string path = HttpContext.Current.Request.MapPath(photopath);        
        
        if (CheckInput() == false)
        {
            ((Label)FormView1.FindControl("lblpname")).Text = input_pname;
            ((Label)FormView1.FindControl("lblpprice")).Text = input_pprice;
            ((Label)FormView1.FindControl("lblfid2")).Text = input_pfid2;
            e.Cancel = true;
        }
        else
        {
            //檢查是否有檔案
                for (int i = 1; i < 4; i++)
                {
                    if (((FileUpload)FormView1.FindControl(string.Format("FileUpload{0}", i))).HasFile)
                    {
                        //取得上載檔案之延伸檔名，並轉換成小寫字母
                        string fileExtension = System.IO.Path.GetExtension(((FileUpload)FormView1.FindControl(string.Format("FileUpload{0}", i))).FileName).ToLower();
                        //檢查延伸檔名是否符合限定類型
                        for (int j = 0; j < allowExtensions.Length; j++)
                        {
                            if (fileExtension == allowExtensions[j])
                            {
                                fileAllow = true;
                            }
                            else
                            {
                                ((Label)FormView1.FindControl(string.Format("lblphotowarm{0}", i))).Text = "檔案副檔名不符合限定類型";
                            }
                        }
                        if (fileAllow)
                        {
                            //儲存檔案到磁碟，檔案名稱須做唯一性處理
                            //指定相片的GUID檔名
                            Guid PhotoGuid = Guid.NewGuid();
                            ((FileUpload)FormView1.FindControl(string.Format("FileUpload{0}", i))).SaveAs(path + PhotoGuid.ToString() + fileExtension);
                            ViewState["Uploads"] += "<li>" + ((FileUpload)FormView1.FindControl(string.Format("FileUpload{0}", i))).PostedFile.FileName + "</li>";
                            //檔案檔名路徑寫入string
                            str[i] = PhotoGuid.ToString() + fileExtension;
                        }
                        else
                        {
                            ((Label)FormView1.FindControl(string.Format("lblphotowarm{0}", i))).Text = "檔案儲存異常!";
                        }
                    }
                    else
                    {
                        str[i] = "";
                    }
                }


                //上傳資料到資料庫
                DataLibBLL p = new DataLibBLL();
                p.Product_Name = ((TextBox)FormView1.FindControl("txtpname")).Text.Trim();
                p.Product_Price = Convert.ToInt32(((TextBox)FormView1.FindControl("txtpprice")).Text);
                p.Product_Introduction = ((TextBox)FormView1.FindControl("txtpintroduction")).Text;
                p.Product_Specification = ((TextBox)FormView1.FindControl("txtpspecification")).Text;
                p.Product_PhotoPath1 = str[1];
                p.Product_PhotoPath2 = str[2];
                p.Product_PhotoPath3 = str[3]; 
                p.Factory_Id = Convert.ToInt32(((Label)FormView1.FindControl("lblfid1")).Text);

                DataLibDLL obj = new DataLibDLL();
                obj.Insert_Product(p);
                //資料INSERT後轉換網頁
                DataLibDLL obj1 = new DataLibDLL();
                DataSet ds=obj1.Select_Product_lastpid();
                string param ="pid="+ ds.Tables["prd_lastpid"].Rows[0][0].ToString();
                obj = null;
                Response.Redirect("Products_edit.aspx?"+param);

                //FormView1.ChangeMode(FormViewMode.ReadOnly);
                //FillFormView_lastpid();
                //obj = null;

        }
    }

    string input_pname = "";
    string input_pprice = "";
    string input_pfid2 = "";
    protected bool CheckInput() 
    {
        //Input輸入檢查
        bool status = true;
        input_pname = "";
        input_pprice = "";
        input_pfid2 = "";
        //檢查商品名稱不可空白
        if (String.IsNullOrEmpty(((TextBox)FormView1.FindControl("txtpname")).Text.Trim()))
        {
            //((Label)FormView1.FindControl("lblpname")).Text = "商品名稱不可空白";
            status = false;
            input_pname = "商品名稱不可空白";
        }

        if (String.IsNullOrEmpty(((TextBox)FormView1.FindControl("txtpprice")).Text.Trim()))
        {
            //((Label)FormView1.FindControl("lblpprice")).Text = "商品價格不可空白";
            status = false;
            input_pprice = "商品價格不可空白";
        }

        if (String.IsNullOrEmpty(((Label)FormView1.FindControl("lblfid1")).Text.Trim()))
        {
            //((Label)FormView1.FindControl("lblfid2")).Text = "請選擇廠商";
            status = false;
            input_pfid2 = "請選擇廠商";
        }
        return status;
    }

    protected void FormView1_ModeChanging(object sender, FormViewModeEventArgs e)
    {

    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        //回產品細項
        Response.Redirect("products_item.aspx");        
    }
}