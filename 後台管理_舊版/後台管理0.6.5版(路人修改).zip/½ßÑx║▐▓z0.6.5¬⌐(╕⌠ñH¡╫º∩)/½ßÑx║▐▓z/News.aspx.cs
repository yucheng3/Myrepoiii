﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using NPOI.HSSF.UserModel;
using NPOI.HPSF;
using NPOI.HSSF;
using NPOI.POIFS.FileSystem;
using System.Data;
using NPOI.SS.UserModel;
using System.Data.SqlClient;
using System.Configuration;

public partial class 後台管理_News : System.Web.UI.Page
{
    SqlConnectionStringBuilder scsb;
    static int countClick = 0; // 計算功能開關按鈕點擊次數
    string xxx;
    protected void Page_Load(object sender, EventArgs e)
    {
        DataLibDLL dataLib = new DataLibDLL();
        SqlDataSource1.ConnectionString = dataLib.Conn_String();                
    }

    public void btnDDL2_click(object sender,EventArgs e) {
        //xxx = DropDownList2.SelectedValue;
        //Label3.Text = "你點選DDL事件處發成功,點選的是 : " + xxx;
    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        //xxx = DropDownList2.SelectedValue;
        //Label3.Text = "你點選DDL事件處發成功,點選的是 : " + xxx;
    }


/*    
    private string getSelectSql()
    {
        string sql = "SELECT * FROM News WHERE 1=1 ";
        if (!string.IsNullOrEmpty(txtIdStart.Text) && !string.IsNullOrEmpty(txtIdEnd.Text))
            sql += " AND nId>=" + txtIdStart.Text + " AND nId<=" + txtIdEnd.Text;
        if (!string.IsNullOrEmpty(txtSubject.Text))
            sql += " AND nSubject LIKE '%" + txtSubject.Text + "%' ";
        if (!string.IsNullOrEmpty(txtContent.Text))
            sql += " AND nContent LIKE '%" + txtContent.Text + "%' ";
        if (!string.IsNullOrEmpty(txtDate.Text))
            sql += " AND nDate LIKE '%" + txtDate.Text + "%' ";       
        return sql;
    }
*/
    private string getSelectSql()
    {
        string sql = "SELECT * FROM News WHERE 1=1 ";
        if (!string.IsNullOrEmpty(TextBox2.Text))
        {
            sql += " AND " + DropDownList2.SelectedValue + " LIKE '%" + TextBox2.Text + "%' ";
        }
        return sql;
    }

    protected void btnMultiSearch_Click(object sender, EventArgs e)
    {
        DropDownList2_selectItem.InnerText = ""; //清空DropDownList2_selectItem提示字
        if (DropDownList2.SelectedValue != "")
        {
            SqlDataSource1.SelectCommand = getSelectSql();
            ListView1.DataBind();
        }
        else {
            DropDownList2_selectItem.InnerText = "請選擇搜尋項目";
        }

    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        this.btnMultiSearch_Click(sender, e);


    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        this.btnMultiSearch_Click(sender, e);

    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        this.btnMultiSearch_Click(sender, e);

    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        this.btnMultiSearch_Click(sender, e);

    }

}