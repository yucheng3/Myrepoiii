﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class 後台管理_MemberInsert : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMessage.Visible = false;
    }
    protected void FormView1_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {
        Response.Redirect("Member.aspx");
    }
    protected void FormView1_ItemInserting(object sender, FormViewInsertEventArgs e)
    {
        if (string.IsNullOrEmpty(e.Values["cName"].ToString()))
        {
            lblMessage.Visible = true;
            lblMessage.Text = "注意：姓名是必填欄位！";
            e.Cancel = true;
        }
    }
}