﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using NPOI.HSSF.UserModel;
using NPOI.HPSF;
using NPOI.HSSF;
using NPOI.POIFS.FileSystem;
using System.Data;
using NPOI.SS.UserModel;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI.HtmlControls;

public partial class 後台管理_Orders : System.Web.UI.Page
{
    SqlConnectionStringBuilder scsb;
    static int countClick = 0; // 計算功能開關按鈕點擊次數

    protected void Page_Load(object sender, EventArgs e)
    {
        DataLibDLL dataLib = new DataLibDLL();
        //SqlDataSource1.ConnectionString = dataLib.Conn_String(); //前看砍了沒有註解,這些可以考慮砍了
        //SqlDataSource2.ConnectionString = dataLib.Conn_String();
        //SqlDataSource3.ConnectionString = dataLib.Conn_String();                   
        //GridView3.Visible = false; //我猜不透高手為啥麼要在這邊設Visible, 想不透啊!!!想不透阿...

        if (IsPostBack) {
            SourceCustomerProducts.SelectCommand = scp_sc;
        }

    }   

    /*新的開始150618*/
    static string cId;
    static string scp_sc;
    public void btnToCustomerProduct_click(object sender,EventArgs e) {
        string cName = ((Button)sender).ToolTip;
        cId = ((Button)sender).Text; //Table CustomerDetails=id , CustomerProducts=CustomerID
        Session["cName"] = cName;        
        scp_sc = "SELECT pro.*, cp.CustomerID, cp.ProductID, cp.TotalProduct FROM [Products] pro inner join [CustomerProducts] cp on pro.pId=cp.ProductID Where cp.CustomerID = '" + cId + "'";
        SourceCustomerProducts.SelectCommand = scp_sc;
        ListView2.DataSourceID = "SourceCustomerProducts";
        ListView2.DataBind();
        GroupCustomerProducts_h1.InnerText = cName + "的全部訂單" + "  共" + ListView2.Items.Count.ToString() + "筆";
        //Session["Customer"] = SourceCustomerProducts.SelectCommand;

        SourceCustomer.SelectCommand = "SELECT * FROM [Customer] where cName = '" + cName + "'";
        myModalLabel.InnerText = cName;

        GroupCustomerDetails.Visible = false;
        GroupCustomerProducts.Visible = true;
    }
    //回上一頁
    public void btnToOrderFirst(object sender,EventArgs e) {
        Response.Redirect("../後台管理/Orders.aspx");
    }
    //前往會員管理指定Customer頁面
    public void btnToSelectMember(object sender,EventArgs e) {
        //Response.Redirect("../後台管理/Member.aspx?Customer=" + (string)Session["cName"]);
    }

    public void btnProductView(object sender,EventArgs e) {
        HtmlButton btn = (HtmlButton)sender;
        SourceProduct.SelectCommand = "SELECT * FROM [Product] where pId = '" + btn.Attributes["name"].ToString() + "'";
    }



                        /*高手的遺留物品*/
                /*今天被我砍了哈哈哈哈哈150622*/
                /*潮爽得!~~看一次爽一次!150623*/     
                /*150625高手請假,沒有過來哈哈哈我再在嗆她一次*/         
}